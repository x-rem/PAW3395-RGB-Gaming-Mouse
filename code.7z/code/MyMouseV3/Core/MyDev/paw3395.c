/*
 * paw3395.c
 *
 *  Created on: May 3, 2025
 *      Author: X
 */

#include "paw3395.h"


void write_reg(uint8_t addr,uint8_t val)
{
	CS_LOW;
	addr |= 0x80;
	Delay_us(1);
	HAL_SPI_Transmit(&hspi1,&addr,1,1000);
	HAL_SPI_Transmit(&hspi1,&val,1,1000);
	CS_HIGH;
	Delay_us(5);
}

uint8_t read_reg(uint8_t addr)
{
	uint8_t data = 0;
	CS_LOW;
	addr += 0x00;
	Delay_us(1);
	HAL_SPI_Transmit(&hspi1,&addr,1,1000);
	Delay_us(5);
	HAL_SPI_Receive(&hspi1,&data, 1, 1000);
	CS_HIGH;
	Delay_us(5);
	return data;
}


uint8_t Product_ID(void)
{
	uint8_t id = 0;
	id = read_reg(0x00);
	return id;
}


uint8_t Revision_ID(void)
{
	uint8_t id = 0;
	id = read_reg(0x01);
	return id;
}

void Motion_Burst(uint8_t *buffer)
{
	uint8_t Motion_Brust_addr = 0x16;
	//Lower NCS
	CS_LOW;
	//Wait for t(NCS-SCLK)
	Delay_us(1);
	//Send Motion_Brust address(0x16)
	HAL_SPI_Transmit(&hspi1,&Motion_Brust_addr,1,1000);
	//Wait for tSRAD
	Delay_us(2);
	//Start reading SPI data continuously up to 12 bytes.
	for(uint8_t i = 0;i < 12;i++)
	{
		HAL_SPI_Receive(&hspi1,&buffer[i], 1, 1000);
	}
	CS_HIGH;
	Delay_us(1);
}


void Corded_Mode(void)
{
	CS_LOW;
	Delay_us(1);
	write_reg(0x7F, 0x05);
	write_reg(0x51, 0x40);
	write_reg(0x53, 0x40);
	write_reg(0x61, 0x31);
	write_reg(0x6E, 0x0F);
	write_reg(0x7F, 0x07);
	write_reg(0x42, 0x2F);
	write_reg(0x43, 0x00);
	write_reg(0x7F, 0x0D);
	write_reg(0x51, 0x12);
	write_reg(0x52, 0xDB);
	write_reg(0x53, 0x12);
	write_reg(0x54, 0xDC);
	write_reg(0x55, 0x12);
	write_reg(0x56, 0xEA);
	write_reg(0x57, 0x15);
	write_reg(0x58, 0x2D);
	write_reg(0x7F, 0x00);
	write_reg(0x54, 0x55);
	write_reg(0x40, 0x83);
	CS_HIGH;
	Delay_us(1);
}

uint8_t Read_PerReg(void)
{
	uint8_t data = 0;
	CS_LOW;
	data = read_reg(0x40);
	CS_HIGH;
	Delay_us(1);
	return data;
}

uint8_t Get_AXIS_CONTROL(void)
{
	uint8_t data = 0;
	CS_LOW;
	data = read_reg(AXIS_CONTROL);
	CS_HIGH;
	Delay_us(1);
	return data;
}


uint8_t INV_PROD_ID(void)
{
	uint8_t id = 0;
	id = read_reg(0x5f);
	return id;
}

void Ripple_Ctrl(uint8_t op)
{
	uint8_t temp = 0;
	temp = read_reg(RIPPLE_CONTROL);
	
	if(op){temp |= 0x80;}
	else{temp &= 0x7F;}
	write_reg(RIPPLE_CONTROL,temp);
	Delay_us(1);
}

void Set_Res(uint8_t res_low,uint8_t res_high,uint8_t op)
{

//	Ripple_Ctrl(op);
	
	CS_LOW;
	Delay_us(1);
	//x and y resolution will determine by RESOLUTION_X
//	write_reg(MOTION_CTRL,0x00);
	
	
	write_reg(RESOLUTION_X_LOW, res_low);
	write_reg(RESOLUTION_X_HIGH, res_high);
	write_reg(SET_RESOLUTION,0x01);
	
	
	write_reg(RESOLUTION_Y_LOW, res_low);
	write_reg(RESOLUTION_Y_HIGH, res_high);
	write_reg(SET_RESOLUTION,0x01);
	//update res
	
	
	CS_HIGH;
	Delay_us(1);
}

uint16_t Get_Res(void)
{
	uint16_t data = 0;
	CS_LOW;
	Delay_us(1);
	data = read_reg(RESOLUTION_X_LOW);
	data |= (read_reg(RESOLUTION_X_HIGH) << 8);
	CS_HIGH;
	Delay_us(1);
	return data;
}

uint16_t Get_Res_Y(void)
{
	uint16_t data = 0;
	CS_LOW;
	Delay_us(1);
	data = read_reg(RESOLUTION_Y_LOW);
	data |= (read_reg(RESOLUTION_Y_HIGH) << 8);
	CS_HIGH;
	Delay_us(1);
	return data;
}



void Power_Up(void)
{
	
	
	//Wait for at least 50ms
	Delay_ms(50);
	CS_LOW;
	Delay_us(1);
	//3. Drive NCS high, and then low to reset the SPI port.
	CS_HIGH;
	Delay_us(1);
	CS_LOW;
	Delay_us(1);
	//4. Write 0x5A to Power_Up_Reset register
	write_reg(Power_Up_Reset,0X5A);
	//5. Wait for at least 5ms.
	Delay_ms(6);
	//6. Load Power-up initialization register setting.

	
	uint8_t read_tmp;
	uint8_t i ;
	write_reg(0x7F ,0x07);
	write_reg(0x40 ,0x41);
	write_reg(0x7F ,0x00);
	write_reg(0x40 ,0x80);
	write_reg(0x7F ,0x0E);
	write_reg(0x55 ,0x0D);
	write_reg(0x56 ,0x1B);
	write_reg(0x57 ,0xE8);
	write_reg(0x58 ,0xD5);
	write_reg(0x7F ,0x14);
	write_reg(0x42 ,0xBC);
	write_reg(0x43 ,0x74);
	write_reg(0x4B ,0x20);
	write_reg(0x4D ,0x00);
	write_reg(0x53 ,0x0E);
	write_reg(0x7F ,0x05);
	write_reg(0x44 ,0x04);
	write_reg(0x4D ,0x06);
	write_reg(0x51 ,0x40);
	write_reg(0x53 ,0x40);
	write_reg(0x55 ,0xCA);
	write_reg(0x5A ,0xE8);
	write_reg(0x5B ,0xEA);
	write_reg(0x61 ,0x31);
	write_reg(0x62 ,0x64);
	write_reg(0x6D ,0xB8);
	write_reg(0x6E ,0x0F);

	write_reg(0x70 ,0x02);
	write_reg(0x4A ,0x2A);
	write_reg(0x60 ,0x26);
	write_reg(0x7F ,0x06);
	write_reg(0x6D ,0x70);
	write_reg(0x6E ,0x60);
	write_reg(0x6F ,0x04);
	write_reg(0x53 ,0x02);
	write_reg(0x55 ,0x11);
	write_reg(0x7A ,0x01);
	write_reg(0x7D ,0x51);
	write_reg(0x7F ,0x07);
	write_reg(0x41 ,0x10);
	write_reg(0x42 ,0x32);
	write_reg(0x43 ,0x00);
	write_reg(0x7F ,0x08);
	write_reg(0x71 ,0x4F);
	write_reg(0x7F ,0x09);
	write_reg(0x62 ,0x1F);
	write_reg(0x63 ,0x1F);
	write_reg(0x65 ,0x03);
	write_reg(0x66 ,0x03);
	write_reg(0x67 ,0x1F);
	write_reg(0x68 ,0x1F);
	write_reg(0x69 ,0x03);
	write_reg(0x6A ,0x03);
	write_reg(0x6C ,0x1F);

	write_reg(0x6D ,0x1F);
	write_reg(0x51 ,0x04);
	write_reg(0x53 ,0x20);
	write_reg(0x54 ,0x20);
	write_reg(0x71 ,0x0C);
	write_reg(0x72 ,0x07);
	write_reg(0x73 ,0x07);
	write_reg(0x7F ,0x0A);
	write_reg(0x4A ,0x14);
	write_reg(0x4C ,0x14);
	write_reg(0x55 ,0x19);
	write_reg(0x7F ,0x14);
	write_reg(0x4B ,0x30);
	write_reg(0x4C ,0x03);
	write_reg(0x61 ,0x0B);
	write_reg(0x62 ,0x0A);
	write_reg(0x63 ,0x02);
	write_reg(0x7F ,0x15);
	write_reg(0x4C ,0x02);
	write_reg(0x56 ,0x02);
	write_reg(0x41 ,0x91);
	write_reg(0x4D ,0x0A);
	write_reg(0x7F ,0x0C);
	write_reg(0x4A ,0x10);
	write_reg(0x4B ,0x0C);
	write_reg(0x4C ,0x40);
	write_reg(0x41 ,0x25);
	write_reg(0x55 ,0x18);
	write_reg(0x56 ,0x14);
	write_reg(0x49 ,0x0A);
	write_reg(0x42 ,0x00);
	write_reg(0x43 ,0x2D);
	write_reg(0x44 ,0x0C);
	write_reg(0x54 ,0x1A);
	write_reg(0x5A ,0x0D);
	write_reg(0x5F ,0x1E);
	write_reg(0x5B ,0x05);
	write_reg(0x5E ,0x0F);
	write_reg(0x7F ,0x0D);
	write_reg(0x48 ,0xDD);
	write_reg(0x4F ,0x03);
	write_reg(0x52 ,0x49);
		
	write_reg(0x51 ,0x00);
	write_reg(0x54 ,0x5B);
	write_reg(0x53 ,0x00);
		
	write_reg(0x56 ,0x64);
	write_reg(0x55 ,0x00);
	write_reg(0x58 ,0xA5);
	write_reg(0x57 ,0x02);
	write_reg(0x5A ,0x29);
	write_reg(0x5B ,0x47);
	write_reg(0x5C ,0x81);
	write_reg(0x5D ,0x40);
	write_reg(0x71 ,0xDC);
	write_reg(0x70 ,0x07);
	write_reg(0x73 ,0x00);
	write_reg(0x72 ,0x08);
	write_reg(0x75 ,0xDC);
	write_reg(0x74 ,0x07);
	write_reg(0x77 ,0x00);
	write_reg(0x76 ,0x08);
	write_reg(0x7F ,0x10);
	write_reg(0x4C ,0xD0);
	write_reg(0x7F ,0x00);
	write_reg(0x4F ,0x63);
	write_reg(0x4E ,0x00);
	write_reg(0x52 ,0x63);
	write_reg(0x51 ,0x00);
	write_reg(0x54 ,0x54);
	write_reg(0x5A ,0x10);
	write_reg(0x77 ,0x4F);
	write_reg(0x47 ,0x01);
	write_reg(0x5B ,0x40);
	write_reg(0x64 ,0x60);
	write_reg(0x65 ,0x06);
	write_reg(0x66 ,0x13);
	write_reg(0x67 ,0x0F);
	write_reg(0x78 ,0x01);
	write_reg(0x79 ,0x9C);
	write_reg(0x40 ,0x00);
	write_reg(0x55 ,0x02);
	write_reg(0x23 ,0x70);
	write_reg(0x22 ,0x01);

	//Wait for 1ms
	Delay_ms(1);
	
	for( i = 0 ;i < 60 ;i++)
	{
		read_tmp = read_reg(0x6C);
		if(read_tmp == 0x80 )
			break;
		Delay_ms(1);
	}
	if(i == 60)
	{
		write_reg(0x7F ,0x14);
		write_reg(0x6C ,0x00);
		write_reg(0x7F ,0x00);
	}
	write_reg(0x22 ,0x00);
	write_reg(0x55 ,0x00);
	write_reg(0x7F ,0x07);
	write_reg(0x40 ,0x40);
	write_reg(0x7F ,0x00);
	
	CS_HIGH;
	Delay_us(1);
	//7. Read registers 0x02, 0x03, 0x04, 0x05 and 0x06 one time 
	// regardless of the motion bit state.
	for(uint8_t j = 0x02;i<0x07;++j)
	{
		read_reg(j);
		Delay_us(2);
	}
	CS_HIGH;
	Delay_us(1);
}


