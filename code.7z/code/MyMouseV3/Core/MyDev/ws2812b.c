/*
 * ws2812b.c
 *
 *  Created on: Apr 16, 2025
 *      Author: X
 */


#include "ws2812b.h"





#define max(a,b) ((a) > (b) ? (a) : (b))
#define min(a,b) ((a) < (b) ? (a) : (b))
#define max3(a,b,c) (((a) > (b) ? (a) : (b)) > (c) ? ((a) > (b) ? (a) : (b)) : (c))
#define min3(a,b,c) (((a) < (b) ? (a) : (b)) < (c) ? ((a) < (b) ? (a) : (b)) : (c))

const RGB_Color_TypeDef RED      = {255,0,0};
const RGB_Color_TypeDef GREEN    = {0,255,0};
const RGB_Color_TypeDef BLUE     = {0,0,255};
const RGB_Color_TypeDef BLACK    = {0,0,0};
const RGB_Color_TypeDef WHITE    = {255,255,255};

extern TIM_HandleTypeDef htim4;

void rgb2hsv(RGB_Color_TypeDef *rgb, HSV_Color_TypeDef *hsv)
{
	float max, min, delta=0;
	float r = (float)((float)((int)rgb->r)/255);
	float g = (float)((float)((int)rgb->g)/255);
	float b = (float)((float)((int)rgb->b)/255);

	max = max3(r, g, b);
	min = min3(r, g, b);
	delta = (max - min);

	//printf("r:%f, g:%f, b:%f\n", r, g, b);

	if (delta == 0) {
		hsv->h = 0;
	} else {
		if (r == max) {
			hsv->h = ((g-b)/delta)*60;
		} else if (g == max) {
			hsv->h = 120+(((b-r)/delta)*60);
		} else if (b == max) {
			hsv->h = 240 + (((r-g)/delta)*60);
		}

		if (hsv->h < 0) {
			hsv->h += 360;
		}
	}

	if (max == 0) {
		hsv->s = 0;
	} else {
		hsv->s = (float)(delta/max);
	}

	hsv->v = max;
}

void hsv2rgb(HSV_Color_TypeDef *hsv, RGB_Color_TypeDef *rgb)
{
	int i;
	float f,a,b,c;

	float h = hsv->h;
	float s = hsv->s;
	float v = hsv->v;
	if (h >= 360) {
		h = 0;
	}

	if (s == 0) {
		rgb->r = (unsigned char)((int)(v*255));
		rgb->g = (unsigned char)((int)(v*255));
		rgb->b = (unsigned char)((int)(v*255));
	} else {
		h /= 60.0;  // sector 0 to 5, h_max=360 360/60=6[0,1,2,3,4,5]
		i = (int)floor(h); // floor(h)
		f = h-i; // factorial path of h
		a = v * (1-s);
		b = v * (1-s*f);
		c = v * (1-s*(1-f));
		switch(i) {
		case 0:
			rgb->r = (unsigned char)((int)(v*255)); //v*255
			rgb->g = (unsigned char)((int)(c*255)); //c*255;
			rgb->b = (unsigned char)((int)(a*255)); //a*255;
			break;
		case 1:
			rgb->r = (unsigned char)((int)(b*255)); //b*255;
			rgb->g = (unsigned char)((int)(v*255)); //v*255;
			rgb->b = (unsigned char)((int)(a*255)); //a*255;
			break;
		case 2:
			rgb->r = (unsigned char)((int)(a*255)); //a*255;
			rgb->g = (unsigned char)((int)(v*255)); //v*255;
			rgb->b = (unsigned char)((int)(c*255)); //c*255;
			break;
		case 3:
			rgb->r = (unsigned char)((int)(a*255));//a*255;
			rgb->g = (unsigned char)((int)(b*255));//b*255;
			rgb->b = (unsigned char)((int)(v*255));//v*255;
			break;
		case 4:
			rgb->r = (unsigned char)((int)(c*255)); //c*255;
			rgb->g = (unsigned char)((int)(a*255)); //a*255;
			rgb->b = (unsigned char)((int)(v*255)); //v*255;
			break;
		default:
			rgb->r = (unsigned char)((int)(v*255)); //v*255;
			rgb->g = (unsigned char)((int)(a*255)); //a*255;
			rgb->b = (unsigned char)((int)(b*255)); //b*255;
			break;
		}
	}
}

/*二维数组存放最终PWM输出数组，每一行24个
数据代表一个LED，最后一行24个0代表RESET码*/
uint32_t Pixel_Buf[2][24];
void ws2818b_reset(void)
{
	uint8_t i;
	for(i=0;i<24;i++)
	{
		Pixel_Buf[1][i] = 0;
	}
}

void ws2818b_write_buf(RGB_Color_TypeDef Color)
{
	uint8_t i;
	for(i=0;i<8;i++) Pixel_Buf[0][i]   = ( (Color.g & (1 << (7 -i)))? (CODE_1):CODE_0 );//数组某一行0~7转化存放G
	for(i=8;i<16;i++) Pixel_Buf[0][i]  = ( (Color.r & (1 << (15-i)))? (CODE_1):CODE_0 );//数组某一行8~15转化存放R
	for(i=16;i<24;i++) Pixel_Buf[0][i] = ( (Color.b & (1 << (23-i)))? (CODE_1):CODE_0 );//数组某一行16~23转化存放B
	ws2818b_reset();
}

/*
功能：最后一行装在24个0，输出24个周期占空比为0的PWM波，作为最后reset延时，这里总时长为24*1.2=30us > 24us(要求大于24us)
*/



void ws2818b_transmi(void)
{
	HAL_TIM_PWM_Start_DMA(&htim4, TIM_CHANNEL_3, (uint32_t *)Pixel_Buf,48);
}


/*
功能：显示红色
参数：Pixel_Len为显示LED个数
*/
void RGB_RED()
{
	ws2818b_write_buf(RED);
	ws2818b_transmi();
}

void ws2818b_set_color(RGB_Color_TypeDef data)
{
	ws2818b_write_buf(data);
	ws2818b_transmi();
}

/*
功能：显示绿色
*/
void RGB_GREEN()
{
	ws2818b_write_buf(GREEN);
	ws2818b_transmi();
}

/*
功能：显示蓝色
*/
void RGB_BLUE()
{
	ws2818b_write_buf(BLUE);
	ws2818b_transmi();
}

/*
功能：显示白色
*/
void RGB_WHITE()
{
	ws2818b_write_buf(WHITE);
	ws2818b_transmi();
}

void RGB_STOP(void)
{
	ws2818b_write_buf(BLACK);
	ws2818b_transmi();
}

void HAL_TIM_PWM_PulseFinishedCallback(TIM_HandleTypeDef *htim)
{
    HAL_TIM_PWM_Stop_DMA(&htim4,TIM_CHANNEL_3);
}
//也可以继续添加其他颜色，和颜色变化函数等
