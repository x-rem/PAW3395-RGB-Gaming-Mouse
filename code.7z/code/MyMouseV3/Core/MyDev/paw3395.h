/*
 * PAW3395.H
 *
 *  Created on: May 3, 2025
 *      Author: X
 */

#ifndef INC_PAW3395_H_
#define INC_PAW3395_H_
#include "global.h"
#include "delay.h"

#define CS_LOW  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
#define CS_HIGH  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);
#define NRESET_HIGH  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);


#define Power_Up_Reset 0x7D
#define MOTION_CTRL	0x5C
#define SET_RESOLUTION 0x47
#define RESOLUTION_X_LOW 0x48
#define RESOLUTION_X_HIGH 0x49
#define RESOLUTION_Y_LOW 0x4A
#define RESOLUTION_Y_HIGH 0x4B
#define RIPPLE_CONTROL 0x5A
#define AXIS_CONTROL 0x5B

extern SPI_HandleTypeDef hspi1;
//typedef struct
//{
//	uint8_t motion;
//	uint8_t deltaxL;
//	uint8_t deltaxH;
//	uint8_t deltayL;
//	uint8_t deltayH;
//}MousePos;

void Power_Up(void);
uint8_t Product_ID(void);
uint8_t INV_PROD_ID(void);
uint8_t Read_PerReg(void);

uint8_t Revision_ID(void);
void Motion_Burst(uint8_t *buffer);
void Corded_Mode(void);
//MousePos MouseData(void);

void Set_Res(uint8_t res_low,uint8_t res_high,uint8_t op);
uint16_t Get_Res(void);
uint16_t Get_Res_Y(void);
uint8_t Get_AXIS_CONTROL(void);
#endif /* INC_PAW3395_H_ */
