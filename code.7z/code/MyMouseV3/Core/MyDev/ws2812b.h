/*
 * ws2812b.h
 *
 *  Created on: Apr 16, 2025
 *      Author: X
 */

#ifndef MY_DEV_WS2812B_H_
#define MY_DEV_WS2812B_H_

#include "global.h"
#define CODE_1       (60)       //1码定时器计数次数
#define CODE_0       (30)       //0码定时器计数次数

typedef struct
{
	uint8_t r;
	uint8_t g;
	uint8_t b;
}RGB_Color_TypeDef;

typedef struct
{
	float h;
	float s;
	float v;
}HSV_Color_TypeDef;


void RGB_RED(void);  //显示红灯
void RGB_GREEN(void);//显示绿灯
void RGB_BLUE(void); //显示蓝灯
void RGB_WHITE(void);//显示白灯
void RGB_STOP(void);
void hsv2rgb(HSV_Color_TypeDef *hsv, RGB_Color_TypeDef *rgb);
void rgb2hsv(RGB_Color_TypeDef *rgb, HSV_Color_TypeDef *hsv);
void ws2818b_set_color(RGB_Color_TypeDef data);

#endif /* MY_DEV_WS2812B_H_ */
