/*
 * global.h
 *
 *  Created on: May 19, 2025
 *      Author: X
 */

#ifndef INC_GLOBAL_H_
#define INC_GLOBAL_H_

#include "stdint.h"
#include "stm32f1xx_hal.h"
#include "stm32f1xx_hal_tim.h"
#include <math.h>
#include "string.h"

#endif /* INC_GLOBAL_H_ */
