/*
 * usb_msg.h
 *
 *  Created on: May 8, 2025
 *      Author: X
 */

#ifndef MY_API_USB_MSG_H_
#define MY_API_USB_MSG_H_
#include "global.h"
#include "usbd_customhid.h"

uint8_t MOUSE_SendReport(USBD_HandleTypeDef  *pdev, uint8_t *report, uint16_t len);
uint8_t KEYBOADR_SendReport(USBD_HandleTypeDef  *pdev, uint8_t *report, uint16_t len);
#endif /* MY_API_USB_MSG_H_ */
