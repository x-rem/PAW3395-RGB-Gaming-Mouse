/*
 * Api_Btn.h
 *
 *  Created on: May 19, 2025
 *      Author: X
 */

#ifndef MYAPI_API_BTN_H_
#define MYAPI_API_BTN_H_
#include "global.h"


#define Lkey_Pin GPIO_PIN_2
#define Lkey_GPIO_Port GPIOA

#define Rkey_Pin GPIO_PIN_0
#define Rkey_GPIO_Port GPIOB

#define Fkey_Pin GPIO_PIN_10
#define Fkey_GPIO_Port GPIOB

#define Bkey_Pin GPIO_PIN_11
#define Bkey_GPIO_Port GPIOB

#define Midkey_Pin GPIO_PIN_9
#define Midkey_GPIO_Port GPIOB

#define Dpikey_Pin GPIO_PIN_12
#define Dpikey_GPIO_Port GPIOB

void Api_BtnInit(void);
void Api_BtnScan(void);
#endif /* MYAPI_API_BTN_H_ */
