/*
 * Api_Task.h
 *
 *  Created on: May 19, 2025
 *      Author: X
 */

#ifndef MYAPI_API_TASK_H_
#define MYAPI_API_TASK_H_
#include "global.h"



#define TASKNUM_MAX	6
typedef struct{
	void (*pTask)(void);    //任务函数
	uint16_t TaskPeriod;    //多少毫秒调用一次任务函数
}TaskStruct;

void Task_Init(void);
void Task_Run(void);
void Api_Rgb(void);
#endif /* MYAPI_API_TASK_H_ */
