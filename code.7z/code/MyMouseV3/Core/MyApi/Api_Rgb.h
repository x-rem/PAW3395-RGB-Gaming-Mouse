/*
 * Api_Rgb.h
 *
 *  Created on: May 20, 2025
 *      Author: X
 */

#ifndef MYAPI_API_RGB_H_
#define MYAPI_API_RGB_H_
#include "global.h"

void Api_RgbCtrl(void);
void Api_InitRgb(void);
void Api_Rgb(void);
#endif /* MYAPI_API_RGB_H_ */
