/*
 * Api_Mouse.c
 *
 *  Created on: May 19, 2025
 *      Author: X
 */


#include "Api_Mouse.h"
#include "Api_MouseConfig.h"
#include "paw3395.h"
#include "usbd_customhid.h"
#include "usb_msg.h"
#include "stdio.h"
#include "Api_Rgb.h"
extern USBD_HandleTypeDef hUsbDeviceFS;
extern Mouse_Config mouseConf;
extern TIM_HandleTypeDef htim2;
uint8_t Mouse_Buffer[6] = {0};
uint8_t Keyboard_Buffer[8] = {0};
uint8_t Btn_Arr[6] = {0};

void setBaseDpi(void)
{
	switch(mouseConf.dpi_slot)
	{
	case 0x01:
	{
		Set_Res(mouseConf.dpi_slot1_low,mouseConf.dpi_slot1_high,0);
		break;
	}
	case 0x02:
	{
		Set_Res(mouseConf.dpi_slot2_low,mouseConf.dpi_slot2_high,0);
		break;
	}
	case 0x03:
	{
		Set_Res(mouseConf.dpi_slot3_low,mouseConf.dpi_slot3_high,0);
		break;
	}
	default:
		break;
	}
}
void Api_MouseInit(void)
{
	Read_Config(&mouseConf);
	if(mouseConf.dpi_slot1_high == 0xff 
			&& mouseConf.dpi_slot1_low == 0xff 
			&& mouseConf.dpi_slot2_high == 0xff
			&& mouseConf.dpi_slot2_low == 0xff
			&& mouseConf.dpi_slot3_high == 0xff
			&& mouseConf.dpi_slot3_low == 0xff
			&& mouseConf.rgb_mode == 0xff
			)
	{
		mouseConf.dpi_slot1_high = 0x00;
		mouseConf.dpi_slot1_low = 0x17;
		mouseConf.dpi_slot2_high = 0x00;
		mouseConf.dpi_slot2_low = 0x23;
		mouseConf.dpi_slot3_high = 0x00;
		mouseConf.dpi_slot3_low = 0x50;
		mouseConf.dpi_slot = 0x01;
		mouseConf.dpi_key_func = 0xff;
		mouseConf.forward_key_func = 0xff;
		mouseConf.back_key_func = 0xff;
		mouseConf.dpi_num = 0x03;
		
		mouseConf.rgb_mode = 0x01;
		mouseConf.rgb_color_r = 0xff;
		mouseConf.rgb_color_g = 0xff;
		mouseConf.rgb_color_b = 0xff;
		
		mouseConf.rgb_bright = 0.1;
		mouseConf.rgb_speed = 0.1;
		Save_Config(&mouseConf);
	}
	NRESET_HIGH;
	Power_Up();
	Corded_Mode();
	setBaseDpi();
	Api_InitRgb();
}

void Api_UpdatePoint(void)
{
	uint8_t burstData[12] = {0};
	Motion_Burst(burstData);
	
	
	Mouse_Buffer[1] = burstData[2];      //x.low
	Mouse_Buffer[2] = burstData[3];     //x.high
	Mouse_Buffer[3] = burstData[4];      //y.low
	Mouse_Buffer[4] = burstData[5];     //x.high
	MOUSE_SendReport(&hUsbDeviceFS,Mouse_Buffer, sizeof(Mouse_Buffer));
	Mouse_Buffer[5] = 0x00;
}

void Api_UpdateBtn(void)
{
	KEYBOADR_SendReport(&hUsbDeviceFS,Keyboard_Buffer, sizeof(Keyboard_Buffer));
}




void Api_UpdateWheel(void)
{
	int16_t num = __HAL_TIM_GET_COUNTER(&htim2);
	if(num >= 2)
	{
		Mouse_Buffer[5] = 0x01;
		TIM2->CNT = 0;
	}
	else if(num <= -2)
	{
		Mouse_Buffer[5] = 0xff;
		TIM2->CNT = 0;
	}
	else
	{
		Mouse_Buffer[5] = 0x80;
	}
}



