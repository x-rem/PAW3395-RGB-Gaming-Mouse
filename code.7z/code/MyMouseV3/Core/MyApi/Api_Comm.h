/*
 * Api_Comm.h
 *
 *  Created on: May 19, 2025
 *      Author: X
 */

#ifndef MYAPI_API_COMM_H_
#define MYAPI_API_COMM_H_

#include "global.h"


void Api_Communicate(void);
#endif /* MYAPI_API_COMM_H_ */
