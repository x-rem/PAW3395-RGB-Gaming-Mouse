/*
 * mouse_config.h
 *
 *  Created on: May 8, 2025
 *      Author: X
 */

#ifndef MY_API_MOUSE_CONFIG_H_
#define MY_API_MOUSE_CONFIG_H_
#include "global.h"

#define FLASH_SAVE_ADDR 0x0800F700

typedef struct
{
	uint8_t dpi_slot;
	uint8_t dpi_key_func;//if it's 0xff,that means use base function,other is keyboard function
	uint8_t forward_key_func;
	uint8_t back_key_func;
	
	uint8_t dpi_num;//max 3
	uint8_t dpi_reverse;
	uint8_t dpi_slot1_high;
	uint8_t dpi_slot1_low;
	uint8_t dpi_slot2_high;
	uint8_t dpi_slot2_low;
	uint8_t dpi_slot3_high;
	uint8_t dpi_slot3_low;
	
	uint8_t rgb_mode;
	uint8_t rgb_color_r;
	uint8_t rgb_color_g;
	uint8_t rgb_color_b;
	
	float rgb_bright;
	float rgb_speed;
	
}Mouse_Config;

//a full config
//01 ff ff ff 03 ff 00 17 00 17 00 17 01 ff ff ff 01 02 03 04 01 02 03 04
void Save_Config(Mouse_Config* config);
void Read_Config(Mouse_Config* config);

#endif /* MY_API_MOUSE_CONFIG_H_ */
