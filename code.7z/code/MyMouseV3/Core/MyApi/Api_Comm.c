/*
 * Api_Comm.c
 *
 *  Created on: May 19, 2025
 *      Author: X
 */


#include "Api_Comm.h"
#include "Api_Mouse.h"
#include "Api_MouseConfig.h"
#include "Api_Rgb.h"
#include "usbd_customhid.h"
#include "stdio.h"

extern USBD_HandleTypeDef hUsbDeviceFS;


extern Mouse_Config mouseConf;
uint8_t recv_buf[64] = {0};
uint8_t send_buf[64] = {0};

void send_success()
{
	send_buf[0] = 0x14;
	send_buf[1] = 0x33;
	while(USBD_CUSTOM_HID_SendReport(&hUsbDeviceFS, 
			send_buf, sizeof(send_buf)));
}

void Analyse_Msg()
{
	if(recv_buf[0] == 0xfe)
	{
		//operation..
		switch(recv_buf[1])
		{
		case 0x01:
			//modify button;
		{
//			printf("Mouse_Config size: %d\r\n",sizeof(Mouse_Config));
//			send_buf[0] = Get_SensorId();
//			send_buf[1] = Get_SensorRId();
			mouseConf.dpi_key_func = recv_buf[2];
			mouseConf.forward_key_func  = recv_buf[3];
			mouseConf.back_key_func = recv_buf[4];
			Save_Config(&mouseConf);
			send_success();
			//1:busy  0:ok
			break;
		}
			
		case 0x02:
			//modify dpi;
		{
			printf("setRes\r\n");
			

			mouseConf.dpi_slot1_low = recv_buf[2];
			mouseConf.dpi_slot1_high = recv_buf[3];
			
			mouseConf.dpi_slot2_low = recv_buf[4];
			mouseConf.dpi_slot2_high = recv_buf[5];	
			
			mouseConf.dpi_slot3_low = recv_buf[6];
			mouseConf.dpi_slot3_high = recv_buf[7];
			mouseConf.dpi_slot =  recv_buf[8];
//			Set_Dpi(mouseConf.dpi_slot1_low,mouseConf.dpi_slot1_high,0);
			Save_Config(&mouseConf);
			setBaseDpi();
			send_success();
			break;
		}
			
		case 0x03:
			//modify rgb;
		{
			mouseConf.rgb_mode = recv_buf[2];
			mouseConf.rgb_color_r = recv_buf[3];
			mouseConf.rgb_color_g = recv_buf[4];
			mouseConf.rgb_color_b = recv_buf[5];
			
			
		    uint8_t *ptr_bright = (uint8_t *)&mouseConf.rgb_bright;
		    for (int i = 0; i < 4; i++) {
		        ptr_bright[i] = recv_buf[6 + i];
		    }

		    uint8_t *ptr_speed = (uint8_t *)&mouseConf.rgb_speed;
		    for (int i = 0; i < 4; i++) {
		        ptr_speed[i] = recv_buf[10 + i];
		    }
		    
		    Save_Config(&mouseConf);
		    Api_InitRgb();
		    send_success();
			break;
		}
		case 0x04:
		{
			//read mouse config
			Read_Config(&mouseConf);
			memcpy(send_buf, &mouseConf, sizeof(Mouse_Config));
			while(USBD_CUSTOM_HID_SendReport(&hUsbDeviceFS, 
					send_buf, sizeof(send_buf)));
			break;
		}
		case 0x05:
		{
			//modify all config
			memcpy(&mouseConf, &recv_buf[2], sizeof(Mouse_Config));
			Save_Config(&mouseConf);
			send_success();
			break;
		}
		case 0x06:
		{
			printf("test success\r\n");
			printf("stm32 float: %d\r\n",sizeof(float));
			send_success();
			break;
		}
		default:
			//todo;
			break;
		}
	}
}
void Api_Communicate(void)
{
	USBD_StatusTypeDef status = USBD_LL_PrepareReceive(&hUsbDeviceFS, 
		  					CUSTOM_HID_EPOUT_ADDR, recv_buf, sizeof(recv_buf));
	if(status == USBD_OK)
	{
		Analyse_Msg();
	}
	memset(recv_buf,0,sizeof(recv_buf));
	memset(send_buf,0,sizeof(send_buf));
}
