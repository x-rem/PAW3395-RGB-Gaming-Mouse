/*
 * Api_Rgb.c
 *
 *  Created on: May 20, 2025
 *      Author: X
 */

#include "Api_Rgb.h"
#include "ws2812b.h"
#include "Api_MouseConfig.h"

extern Mouse_Config mouseConf;

float chroma_speed = 1; //0.1-1
float breath_speed = 0.01;//0.01-0.1

RGB_Color_TypeDef chroma_rgb = {0,0,0xff};
HSV_Color_TypeDef chroma_hsv = {0.0f, 1.0f, 1.0f};


RGB_Color_TypeDef breath_rgb = {0};
HSV_Color_TypeDef breath_hsv = {0.0f, 1.0f, 1.0f};

RGB_Color_TypeDef normal_rgb = {0};
float breathV_value = 1.0f;



uint8_t chroma_up = 1;
uint8_t chroma_down = 0;


uint8_t breath_up = 1;
uint8_t breath_down = 0;
void chroma(void)
{
	if(chroma_hsv.h <=0)
	{
		chroma_up = 1;
		chroma_down = 0;
	}
	  
	if(chroma_hsv.h >= 360)
	{
		chroma_hsv.h = 360;
		chroma_down = 1;
		chroma_up = 0;
	}
	hsv2rgb(&chroma_hsv,&chroma_rgb);
	ws2818b_set_color(chroma_rgb);
	if(chroma_up){chroma_hsv.h += chroma_speed;}
	if(chroma_down){chroma_hsv.h -= chroma_speed;}
}

void breath(void)
{
	if(breath_hsv.v >= breathV_value)
	{
		breath_hsv.v = breathV_value;
		breath_down = 1;
		breath_up = 0;
	}
	if(breath_hsv.v <= 0.1)
	{
		breath_up = 1;
		breath_down = 0;
	}
			
	hsv2rgb(&breath_hsv,&breath_rgb);
	ws2818b_set_color(breath_rgb);

	if(breath_up){breath_hsv.v += breath_speed;}
	if(breath_down){breath_hsv.v -= breath_speed;}
}
void normal(void)
{
	ws2818b_set_color(normal_rgb);
}

void Api_InitRgb(void)
{
	chroma_speed = mouseConf.rgb_speed;
	chroma_rgb.r = mouseConf.rgb_color_r;
	chroma_rgb.g = mouseConf.rgb_color_g;
	chroma_rgb.b = mouseConf.rgb_color_b;
	chroma_hsv.v = mouseConf.rgb_bright;
	
	breath_speed = mouseConf.rgb_speed;
	breath_rgb.r = mouseConf.rgb_color_r;
	breath_rgb.g = mouseConf.rgb_color_g;
	breath_rgb.b = mouseConf.rgb_color_b;
	breath_hsv.v = mouseConf.rgb_bright;
	
	breathV_value = breath_hsv.v;
	//rgb2hsv(&chroma_rgb,&chroma_hsv);
	rgb2hsv(&breath_rgb,&breath_hsv);
	normal_rgb.r =  mouseConf.rgb_color_r;
	normal_rgb.g =  mouseConf.rgb_color_g;
	normal_rgb.b =  mouseConf.rgb_color_b;
}

void Api_Rgb(void)
{
	switch(mouseConf.rgb_mode)
	{
	case 0x00:
	{
		RGB_STOP();
		break;
	}
	case 0x01:
	{
		normal();
		break;
	}
	case 0x02:
	{
		breath();
		break;
	}
	case 0x03:
	{
		chroma();
		break;
	}
	default:
		break;
	}
}
