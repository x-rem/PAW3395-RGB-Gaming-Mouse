/*
 * usb_msg.c
 *
 *  Created on: May 8, 2025
 *      Author: X
 */

#include "usb_msg.h"

uint8_t MOUSE_SendReport(USBD_HandleTypeDef  *pdev, uint8_t *report, uint16_t len) {

    USBD_CUSTOM_HID_HandleTypeDef     *hhid = (USBD_CUSTOM_HID_HandleTypeDef *)pdev->pClassData;

    if (pdev->dev_state == USBD_STATE_CONFIGURED) {
        if (hhid->state == CUSTOM_HID_IDLE) {
            hhid->state = CUSTOM_HID_BUSY;
            USBD_LL_Transmit(pdev, MOUSE_EP, report, len);
        } else {
            return USBD_BUSY;
        }
    }
    return USBD_OK;
}

uint8_t KEYBOADR_SendReport(USBD_HandleTypeDef  *pdev, uint8_t *report, uint16_t len) {

    USBD_CUSTOM_HID_HandleTypeDef     *hhid = (USBD_CUSTOM_HID_HandleTypeDef *)pdev->pClassData;

    if (pdev->dev_state == USBD_STATE_CONFIGURED) {
        if (hhid->state == CUSTOM_HID_IDLE) {
            hhid->state = CUSTOM_HID_BUSY;
            USBD_LL_Transmit(pdev, KEYBOARD_EP, report, len);
        } else {
            return USBD_BUSY;
        }
    }
    return USBD_OK;
}
