/*
 * Api_Mouse.h
 *
 *  Created on: May 19, 2025
 *      Author: X
 */

#ifndef MYAPI_API_MOUSE_H_
#define MYAPI_API_MOUSE_H_
#include "global.h"
void Api_MouseInit(void);
void Api_UpdatePoint(void);
void Api_UpdateBtn(void);
void Api_UpdateWheel(void);
void setBaseDpi(void);
#endif /* MYAPI_API_MOUSE_H_ */
