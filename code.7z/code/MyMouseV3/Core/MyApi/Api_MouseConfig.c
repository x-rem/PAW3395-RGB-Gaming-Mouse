/*
 * mouse_config.c
 *
 *  Created on: May 8, 2025
 *      Author: X
 */


#include "Api_MouseConfig.h"


Mouse_Config mouseConf = {0};

static FLASH_EraseInitTypeDef EraseInitStruct = {
		.TypeErase = FLASH_TYPEERASE_PAGES,
		.PageAddress = FLASH_SAVE_ADDR,
		.NbPages = 1
};

void Save_Config(Mouse_Config* config)
{
	HAL_FLASH_Unlock();
	uint32_t PageError = 0;
	uint32_t* pData = (uint32_t*)config;
	__disable_irq();
	if(HAL_FLASHEx_Erase(&EraseInitStruct,&PageError) == HAL_OK)
	{
		for (int i = 0; i < sizeof(Mouse_Config) / 4; i++)
		{
			if (HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, FLASH_SAVE_ADDR + (i * 4), pData[i]) != HAL_OK)
			{
				HAL_FLASH_Lock();
				return;
			}
		}
	}
	__enable_irq();
	HAL_FLASH_Lock();
}

void Read_Config(Mouse_Config* config)
{
	uint32_t* pData = (uint32_t*)config;  
	for (int i = 0; i < sizeof(Mouse_Config) / 4; i++)  
	{
		pData[i] = *(volatile uint32_t*)(FLASH_SAVE_ADDR + (i * 4));  // read data from flash
	}
}
