/*
 * Api_Btn.c
 *
 *  Created on: May 19, 2025
 *      Author: X
 */


#include "Api_Btn.h"
#include "Api_MouseConfig.h"
#include "stdio.h"
#include "Api_Mouse.h"
extern Mouse_Config mouseConf;

extern uint8_t Mouse_Buffer[6];
extern uint8_t Keyboard_Buffer[8];


uint8_t dpiprevious_state = 0;  // 上一状态
uint8_t dpicurrent_state = 0;   // 当前状态


void keyFunc(uint8_t funcStat,uint8_t baseData,uint8_t keyboardIndex,uint8_t pressed)
{
	if(funcStat == 0xff)
	{
		if(pressed)
			{Mouse_Buffer[0] |= baseData;}
		else
			{Mouse_Buffer[0] &= ~baseData;}
	}
	else
	{
		if(pressed)
			{Keyboard_Buffer[keyboardIndex] |= funcStat;}
		else
			{Keyboard_Buffer[keyboardIndex] &= ~funcStat;}
	}
}

void dpiFunc(uint8_t funcStat,uint8_t keyboardIndex,uint8_t pressed)
{
	if(funcStat == 0xff)
	{
		//using base function
		dpicurrent_state = pressed;
		if(dpicurrent_state == 0 && dpiprevious_state !=0)
		{
			printf("pa\r\n");
		    if (mouseConf.dpi_slot == 0x03) 
		    {
		    	mouseConf.dpi_slot = 0x01;
		    } 
		    else 
		    {
		    	mouseConf.dpi_slot++;
		    }
		    Save_Config(&mouseConf);
		    setBaseDpi();
		}
		dpiprevious_state = dpicurrent_state;
	}
	else
	{
		if(pressed)
			{Keyboard_Buffer[keyboardIndex] |= funcStat;}
		else
			{Keyboard_Buffer[keyboardIndex] &= ~funcStat;}
	}
}

void Api_BtnInit(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	__HAL_RCC_GPIOD_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	
	
	GPIO_InitStruct.Pin = Lkey_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	
	GPIO_InitStruct.Pin = Rkey_Pin|Midkey_Pin|Fkey_Pin|Bkey_Pin|Dpikey_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
}



void Api_BtnScan(void)
{
	if(HAL_GPIO_ReadPin(Lkey_GPIO_Port, Lkey_Pin) == 0){Mouse_Buffer[0] |= 0x01;}//Lkey
	else {Mouse_Buffer[0] &= ~0x01;}
	
	if(HAL_GPIO_ReadPin(Rkey_GPIO_Port, Rkey_Pin) == 0){Mouse_Buffer[0] |= 0x02;}//Rkey
	else {Mouse_Buffer[0] &= ~0x02;}

	if(HAL_GPIO_ReadPin(Midkey_GPIO_Port, Midkey_Pin) == 0){Mouse_Buffer[0] |= 0x04;}//Midkey
	else {Mouse_Buffer[0] &= ~0x04;}
	
	
	
	
	
	if(HAL_GPIO_ReadPin(Fkey_GPIO_Port, Fkey_Pin) == 0)
	{ 
		keyFunc(mouseConf.forward_key_func,0x10,2,1); 
	}//Fkey
	else 
	{ 
		keyFunc(mouseConf.forward_key_func,0x10,2,0); 
	}
	
	if(HAL_GPIO_ReadPin(Fkey_GPIO_Port, Bkey_Pin) == 0)
	{ 
		keyFunc(mouseConf.back_key_func,0x08,3,1); 
	}//Bkey
	else 
	{ 
		keyFunc(mouseConf.back_key_func,0x08,3,0); 
	}
	
	if(HAL_GPIO_ReadPin(Dpikey_GPIO_Port, Dpikey_Pin) == 0)
	{ 
		dpiFunc(mouseConf.dpi_key_func,4,1); 
	}//DpiKey
	else 
	{ 
		dpiFunc(mouseConf.dpi_key_func,4,0); 
	}
	
	
//	if(HAL_GPIO_ReadPin(Lkey_GPIO_Port, Lkey_Pin) == 0){Mouse_Buffer[0] |= 0x01;}//Lkey
//	else {Mouse_Buffer[0] &= ~0x01;}
//	
//	if(HAL_GPIO_ReadPin(Rkey_GPIO_Port, Rkey_Pin) == 0){Mouse_Buffer[0] |= 0x02;}//Rkey
//	else {Mouse_Buffer[0] &= ~0x02;}
//
//	if(HAL_GPIO_ReadPin(Fkey_GPIO_Port, Fkey_Pin) == 0){Mouse_Buffer[0] |= 0x10;}//Fkey
//	else {Mouse_Buffer[0] &= ~0x10;}
//	
//	if(HAL_GPIO_ReadPin(Fkey_GPIO_Port, Bkey_Pin) == 0){Mouse_Buffer[0] |= 0x08;}//Bkey
//	else {Mouse_Buffer[0] &= ~0x08;}
//	
//	if(HAL_GPIO_ReadPin(Midkey_GPIO_Port, Midkey_Pin) == 0){Mouse_Buffer[0] |= 0x04;}//Midkey
//	else {Mouse_Buffer[0] &= ~0x04;}	
//		
//	if(HAL_GPIO_ReadPin(Dpikey_GPIO_Port, Dpikey_Pin) == 0){Keyboard_Buffer[2] |= 0x04;}
//	else {Keyboard_Buffer[2] &= ~0x04;}
}
