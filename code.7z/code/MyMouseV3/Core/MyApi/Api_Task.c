/*
 * Api_Task.c
 *
 *  Created on: May 19, 2025
 *      Author: X
 */

#include "Api_Task.h"
#include "Api_Mouse.h"
#include "Api_Btn.h"
#include "Api_Comm.h"
#include "Api_Rgb.h"
uint32_t SYS_tick_ms;


uint16_t TaskTimer[TASKNUM_MAX];
TaskStruct Task[] = {
	{Api_BtnScan, 8},
	{Api_UpdatePoint, 1},
	{Api_UpdateWheel, 8},
    {Api_Communicate, 10},
	{Api_UpdateBtn,8},
	{Api_Rgb,20}
};


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *hitm)
{
	uint8_t i;
	
    // 系统总运行时间，可连续计时49.7天
	SYS_tick_ms++;
	
	//HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);
	for(i = 0; i < TASKNUM_MAX; i++){
		if(TaskTimer[i])
			TaskTimer[i]--;
	}	
}

void Task_Init(void)
{
	uint8_t NTask;
	for(NTask = 0; NTask < sizeof(Task)/sizeof(Task[0]); NTask++){
		TaskTimer[NTask] = Task[NTask].TaskPeriod;
	}
}	

void Task_Run(void)
{
	uint8_t NTask;
	for(NTask = 0; NTask < sizeof(Task)/sizeof(Task[0]); NTask++){
		if(TaskTimer[NTask] == 0)
		{
			TaskTimer[NTask] = Task[NTask].TaskPeriod;
			(Task[NTask].pTask)();
		}
	}
}
