#include "mysliderh.h"
 
#include <QPainter>
 
SliderWidget::SliderWidget(int w, int h, QWidget *parent):
    QWidget(parent), m_maxVal(100), m_minVal(0)
{
    this->setFixedSize(w, h);
    m_curPoint = QPoint(11, 0);
}
 
void SliderWidget::setMaxVal(qreal val)
{
    m_maxVal = val;
}
 
void SliderWidget::setMinVal(qreal val)
{
    m_minVal = val;
}
 
void SliderWidget::setVal(qreal val)
{
    m_curVal = val;
    int posX = (this->width() - 22)*(m_curVal - m_minVal)/(m_maxVal - m_minVal) + 11;
    m_curPoint = QPoint(posX, 0);
    update();
}
 
qreal SliderWidget::getCurVal() const
{
    return m_curVal;
}
 
qreal SliderWidget::getMinVal() const
{
    return m_minVal;
}
 
qreal SliderWidget::getMaxVal() const
{
    return m_maxVal;
}
 
void SliderWidget::paintEvent(QPaintEvent *e)
{
    QPainter painter(this);
    painter.setBrush(QColor("#4982d9"));
    painter.setPen(Qt::NoPen);
    painter.setRenderHint(QPainter::Antialiasing);
    painter.drawRoundedRect(QRect(0, this->height()/5*2, m_curPoint.x(),
                                  this->height()/5), 4, 4);
    painter.setBrush(QColor(206, 206, 206));
    painter.drawRoundedRect(QRect(m_curPoint.x(), this->height()/5*2, this->width() - m_curPoint.x(),
                                  this->height()/5), 4, 4);
    QPen pen;
    pen.setWidth(2);
    pen.setColor(QColor(206, 206, 206));
    painter.setBrush(Qt::white);
    painter.setPen(pen);
    painter.drawEllipse(QPointF(m_curPoint.x(), this->height()/2), 10, 10);
 
}
 
void SliderWidget::mousePressEvent(QMouseEvent *event)
{
    getCurPoint(event);
}
 
void SliderWidget::mouseMoveEvent(QMouseEvent *event)
{
    getCurPoint(event);
}
 
void SliderWidget::getCurPoint(QMouseEvent *event)
{
    if(event->pos().x() < 11)
    {
        m_curPoint = QPoint(11, 0);
    }
    else if(event->pos().x() > this->width() - 11)
    {
        m_curPoint = QPoint(this->width() - 11, 0);
    }
    else
    {
        m_curPoint = event->pos();
    }
    update();
 
    m_curVal = (qreal)(m_curPoint.x() - 11)/(this->width() - 22)*(m_maxVal - m_minVal) + m_minVal;
    emit sigPositonChange(m_curVal);
}
