#include "mousespeedpage.h"
#include <QDebug>
#include <iostream>
MouseSpeedPage::MouseSpeedPage(QWidget *parent) : QWidget(parent)
{
    m_baseLayout = new QVBoxLayout(this);
    m_baseLayout->setContentsMargins(10,10,10,10);
    
    dpi1 = new DpiPage(this);
    dpi1->m_dpiTextLabel->setText("DPI 1");
    
    dpi2 = new DpiPage(this);
    dpi2->m_dpiTextLabel->setText("DPI 2");
    
    dpi3 = new DpiPage(this);
    dpi3->m_dpiTextLabel->setText("DPI 3");
    
    
    m_baseLayout->addStretch();
    m_baseLayout->addWidget(dpi1);
    m_baseLayout->addWidget(dpi2);
    m_baseLayout->addWidget(dpi3);
    m_baseLayout->addStretch();
    initBg();
    setLayout(m_baseLayout);
    
}

DpiPage::DpiPage(QWidget *parent) : QWidget(parent)
{
    m_dpiNum = 50;
    m_dpiTextWidget = new QWidget(this);
    m_baseLayout = new QVBoxLayout(this);
    m_dpiLayout = new QHBoxLayout(m_dpiTextWidget);
    m_dpiTextLabel = new QLabel("DPI",m_dpiTextWidget);
    m_dpiNumLabel = new QLabel("50",m_dpiTextWidget);
    m_slider = new SliderWidget(600,50,this);
    
    m_dpiLayout->setContentsMargins(0,0,0,0);
    m_baseLayout->setContentsMargins(0,0,0,0);
    
    m_dpiLayout->addWidget(m_dpiTextLabel);
    m_dpiLayout->addStretch();
    m_dpiLayout->addWidget(m_dpiNumLabel);
    
    m_baseLayout->addWidget(m_dpiTextWidget);
    m_baseLayout->addWidget(m_slider);
    
    connect(m_slider, &SliderWidget::sigPositonChange, this, &DpiPage::setDpiLabelNum);
    
    setLayout(m_baseLayout);
}

void DpiPage::setDpiNumLabelText(uint16_t dpi)
{
    double cpi = 26000;
    double percent = dpi/cpi;
    m_slider->setVal(percent*100);
    m_dpiNum = dpi;
    this->m_dpiNumLabel->setText(QString::number(m_dpiNum));
}

void DpiPage::setDpiLabelNum(qreal curVal)
{
    int cpi = 26000;
    double intVal = static_cast<double>(curVal);  // 转换为整数
    int end = static_cast<int>(cpi * (intVal / 100));
    
    // 将end调整为50的步进
    end = (end / 50) * 50;  // 确保end是50的倍数
    
    // 确保end在50和25600之间
    if (end < 50) {
        end = 50;
    } else if (end > cpi) {
        end = 26000;
    }
    m_dpiNum = end;
    m_dpiNumLabel->setText(QString::number(m_dpiNum));
}


void MouseSpeedPage::initBg()
{
    QPalette palette = this->palette();
    palette.setColor(QPalette::Window, QColor("#f1f5f8"));
    setAutoFillBackground(true);
    setPalette(palette);
}
