#include "pagetest.h"

#include <QApplication>
#include "mousesliderbar.h"
#include "hidapi.h"
#include <iostream>
#include <QVector>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    PageTest w;
    w.show();
    return a.exec();
}
