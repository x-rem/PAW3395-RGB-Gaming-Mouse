#include "ColorPickerWidget.h"
#include <QPainter>
#include <QDebug>

// 定义两个区域的宽度和间距
const int HUE_WIDTH = 20;
const int SV_WIDTH = 200;
const int SV_HEIGHT = 200;
const int PADDING = 10; // 两个区域之间的间距

ColorPickerWidget::ColorPickerWidget(QWidget *parent)
    : QWidget(parent),
      m_currentColor(Qt::red), // 默认初始颜色
      m_isHueDragging(false),
      m_isSVDragging(false)
{
    // 设置固定大小：SV区域宽度 + 间距 + HUE区域宽度
    setFixedSize(SV_WIDTH + PADDING + HUE_WIDTH, SV_HEIGHT);

    // 初始设置m_selectedSVPoint，使其对应m_currentColor的饱和度和亮度
    // 将S和V从0-255映射到SV区域的像素坐标
    m_selectedSVPoint.setX(static_cast<int>(m_currentColor.hsvSaturationF() * (SV_WIDTH - 1)));
    m_selectedSVPoint.setY(static_cast<int>((1.0 - m_currentColor.valueF()) * (SV_HEIGHT - 1))); // 已修正
}

QSize ColorPickerWidget::minimumSizeHint() const
{
    return QSize(SV_WIDTH + PADDING + HUE_WIDTH, SV_HEIGHT);
}

QSize ColorPickerWidget::sizeHint() const
{
    return QSize(SV_WIDTH + PADDING + HUE_WIDTH, SV_HEIGHT);
}

QColor ColorPickerWidget::currentColor() const
{
    return m_currentColor;
}

void ColorPickerWidget::setCurrentColor(const QColor &color)
{
    if (m_currentColor != color) {
        m_currentColor = color;
        // 更新指示器位置
        m_selectedSVPoint.setX(static_cast<int>(m_currentColor.hsvSaturationF() * (SV_WIDTH - 1)));
        m_selectedSVPoint.setY(static_cast<int>((1.0 - m_currentColor.valueF()) * (SV_HEIGHT - 1))); // 已修正
        update(); // 重新绘制
        emit colorChanged(m_currentColor); // 触发颜色改变信号
    }
}

QRect ColorPickerWidget::svRect() const
{
    return QRect(0, 0, SV_WIDTH, SV_HEIGHT);
}

QRect ColorPickerWidget::hueRect() const
{
    return QRect(SV_WIDTH + PADDING, 0, HUE_WIDTH, SV_HEIGHT);
}

void ColorPickerWidget::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing, true);

    // --- 绘制饱和度/亮度区域 ---
    QRect svArea = svRect();
    int currentHue = m_currentColor.hsvHue(); // 获取当前色调

    for (int y = 0; y < svArea.height(); ++y) {
        for (int x = 0; x < svArea.width(); ++x) {
            int saturation = static_cast<int>(255.0 * x / (svArea.width() - 1));
            int value = static_cast<int>(255.0 * (svArea.height() - 1 - y) / (svArea.height() - 1));

            QColor color = QColor::fromHsv(currentHue, saturation, value);
            painter.setPen(color);
            painter.drawPoint(svArea.left() + x, svArea.top() + y);
        }
    }

    // 绘制饱和度/亮度区域的圆点指示器
    painter.setBrush(Qt::NoBrush);
    painter.setPen(QPen(Qt::white, 2));
    painter.drawEllipse(svArea.left() + m_selectedSVPoint.x(), svArea.top() + m_selectedSVPoint.y(), 5, 5); // 中心在点击处，半径5

    painter.setPen(QPen(Qt::black, 1));
    painter.drawEllipse(svArea.left() + m_selectedSVPoint.x(), svArea.top() + m_selectedSVPoint.y(), 4, 4); // 中心在点击处，半径4

    // --- 绘制色调条区域 ---
    QRect hueArea = hueRect();

    for (int y = 0; y < hueArea.height(); ++y) {
        // 将y坐标映射到0-359的色调值
        int hue = static_cast<int>(359.0 * y / (hueArea.height() - 1));
        QColor color = QColor::fromHsv(hue, 255, 255); // S和V固定为255
        painter.setPen(color);
        painter.drawLine(hueArea.left(), hueArea.top() + y, hueArea.right(), hueArea.top() + y);
    }

    // 绘制色调条的箭头指示器
    painter.setBrush(Qt::white);
    painter.setPen(Qt::black);

    QPolygonF arrow;
    int arrowSize = 6;
    // 计算当前色调在色调条上的Y坐标
    int hueArrowY = static_cast<int>(m_currentColor.hsvHueF() * (hueArea.height() - 1));
    int x_pos = hueArea.right(); // 箭头的尖端在右边缘

    arrow << QPointF(x_pos, hueArea.top() + hueArrowY) // 尖端
          << QPointF(x_pos - arrowSize, hueArea.top() + hueArrowY - arrowSize / 2) // 左下角
          << QPointF(x_pos - arrowSize, hueArea.top() + hueArrowY + arrowSize / 2); // 左上角

    painter.drawPolygon(arrow);
}

void ColorPickerWidget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        if (svRect().contains(event->pos())) {
            // 点击了饱和度/亮度区域
            m_isSVDragging = true;
            updateSVFromMouseXY(event->pos().x(), event->pos().y());
        } else if (hueRect().contains(event->pos())) {
            // 点击了色调条区域
            m_isHueDragging = true;
            updateHueFromMouseY(event->pos().y());
        }
        // 任何点击都会触发颜色改变信号和UI更新
        emit colorChanged(m_currentColor);
        update();
    }
}

void ColorPickerWidget::mouseMoveEvent(QMouseEvent *event)
{
    if (event->buttons() & Qt::LeftButton) { // 检查左键是否按下
        bool colorUpdated = false;
        if (m_isSVDragging) {
            updateSVFromMouseXY(event->pos().x(), event->pos().y());
            colorUpdated = true;
        } else if (m_isHueDragging) {
            updateHueFromMouseY(event->pos().y());
            colorUpdated = true;
        }

        if (colorUpdated) {
            emit colorChanged(m_currentColor);
            update(); // 重新绘制，更新指示器和颜色
        }
    }
}

void ColorPickerWidget::mouseReleaseEvent(QMouseEvent *event)
{
    Q_UNUSED(event);
    if (m_isHueDragging || m_isSVDragging) {
        m_isHueDragging = false;
        m_isSVDragging = false;
        // 释放时确保最终颜色被选中并发出信号
        emit colorChanged(m_currentColor);
        update();
    }
}

void ColorPickerWidget::updateHueFromMouseY(int mouseY)
{
    QRect hueArea = hueRect();
    int clampedY = qBound(hueArea.top(), mouseY, hueArea.bottom());
    // 将Y坐标映射到0.0-1.0的浮点数，然后转换为色调
    qreal hueF = static_cast<qreal>(clampedY - hueArea.top()) / (hueArea.height() - 1);
    int newHue = static_cast<int>(hueF * 359.0);

    // 更新m_currentColor的色调，保持饱和度和亮度不变
    // 修正：使用 value() 而不是 hsvValue()
    m_currentColor.setHsv(newHue, m_currentColor.hsvSaturation(), m_currentColor.value());
}

void ColorPickerWidget::updateSVFromMouseXY(int mouseX, int mouseY)
{
    QRect svArea = svRect();
    int clampedX = qBound(svArea.left(), mouseX, svArea.right());
    int clampedY = qBound(svArea.top(), mouseY, svArea.bottom());

    m_selectedSVPoint.setX(clampedX - svArea.left()); // 更新指示点位置
    m_selectedSVPoint.setY(clampedY - svArea.top());

    // 将X,Y坐标映射到0.0-1.0的浮点数，然后转换为饱和度和亮度
    qreal saturationF = static_cast<qreal>(m_selectedSVPoint.x()) / (svArea.width() - 1);
    qreal valueF = 1.0 - static_cast<qreal>(m_selectedSVPoint.y()) / (svArea.height() - 1); // Y轴反向

    int newSaturation = static_cast<int>(saturationF * 255.0);
    int newValue = static_cast<int>(valueF * 255.0);

    // 更新m_currentColor的饱和度和亮度，保持色调不变
    m_currentColor.setHsv(m_currentColor.hsvHue(), newSaturation, newValue);
}
