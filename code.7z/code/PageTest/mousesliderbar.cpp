#include "mousesliderbar.h"

MouseSliderBar::MouseSliderBar(QWidget *parent) : QWidget(parent)
{
    initBg();
    initLayout();
    initLabel();
    setLayout(m_pVlayout);
}

void MouseSliderBar::initBg()
{
    m_bgColor = QColor("#f1f5f8");
    QPalette palette = this->palette();
    palette.setColor(QPalette::Window, m_bgColor);
    setAutoFillBackground(true);
    setPalette(palette);
}


void MouseSliderBar::initLayout()
{
    m_pVlayout = new QVBoxLayout(this);
    m_pVlayout->setContentsMargins(5,5,5,5);
}

void MouseSliderBar::initLabel()
{
    m_pVlayout->addStretch();
    for(int i = 0;i<3;i++)
    {
        MyLabel* label = new MyLabel(this);
        label->setFixedWidth(180);
        label->setFixedHeight(50);
        label->setBgColor(m_bgColor);
        label->setHoverBgColor(QColor("#0bbfff"));
        label->setRadius(5);
        labelList.push_back(label);
        m_pVlayout->addWidget(label);
    }
    labelList[0]->setText("速度设置");
    labelList[1]->setText("按键设置");
    labelList[2]->setText("灯光设置");
    
    m_pVlayout->addStretch();
}
