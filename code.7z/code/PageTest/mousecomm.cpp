#include "mousecomm.h"
#include <cstring>
#include <QDebug>
#include <iostream>

MouseComm::MouseComm()
{
    bufInit();
}

bool MouseComm::modAll(const MouseConfig &mouseConf)
{
    bool stat = false;
    send_buf[2] = 0x05;
    
    return stat;
}

bool MouseComm::modBtn(const MouseConfig &mouseConf, hid_device *mydev)
{
    bool stat = false;
    send_buf[2] = 0x01;
    
    send_buf[3] = mouseConf.dpi_key_func;
    send_buf[4] = mouseConf.forward_key_func;
    send_buf[5] = mouseConf.back_key_func;
    
    hid_write(mydev,send_buf,65);
    //sleep for 2ms
    hid_read_timeout(mydev, recv_buf,64,1000);
    if(recv_buf[0] == 0x14 && recv_buf[1] == 0x33)
        stat = true;
    bufInit();
    return stat;
}

bool MouseComm::modDpi(const MouseConfig &mouseConf,hid_device* mydev)
{
    bool stat = false;
    send_buf[2] = 0x02;
    
    send_buf[3] = mouseConf.dpi_slot1_low;
    send_buf[4] = mouseConf.dpi_slot1_high;
    send_buf[5] = mouseConf.dpi_slot2_low;
    send_buf[6] = mouseConf.dpi_slot2_high;
    send_buf[7] = mouseConf.dpi_slot3_low;
    send_buf[8] = mouseConf.dpi_slot3_high;
    send_buf[9] = mouseConf.dpi_slot;
    
    
    hid_write(mydev,send_buf,65);
    //sleep for 2ms
    hid_read_timeout(mydev, recv_buf,64,1000);
    if(recv_buf[0] == 0x14 && recv_buf[1] == 0x33)
        stat = true;
    bufInit();
    return stat;
}

bool MouseComm::modRgb(const MouseConfig &mouseConf, hid_device *mydev)
{
    bool stat = false;
    send_buf[2] = 0x03;
    send_buf[3] = mouseConf.rgb_mode;
    send_buf[4] = mouseConf.rgb_color_r;
    send_buf[5] = mouseConf.rgb_color_g;
    send_buf[6] = mouseConf.rgb_color_b;
    
    

    uint8_t *ptr_bright = (uint8_t *)&mouseConf.rgb_bright;
    for (int i = 0; i < 4; i++) {
        send_buf[7 + i] = ptr_bright[i];
    }


    uint8_t *ptr_speed = (uint8_t *)&mouseConf.rgb_speed;
    for (int i = 0; i < 4; i++) {
        send_buf[11 + i] = ptr_speed[i];
    }
    
    
    
    hid_write(mydev,send_buf,65);
    //sleep for 2ms
    hid_read_timeout(mydev, recv_buf,64,1000);
    if(recv_buf[0] == 0x14 && recv_buf[1] == 0x33)
        stat = true;
    bufInit();
    return stat;
}

void MouseComm::readCfg(MouseConfig &mouseConf,hid_device* mydev)
{
    bool stat = false;
    send_buf[2] = 0x04;
    hid_write(mydev,send_buf,65);
    int ret = hid_read_timeout(mydev, recv_buf,64,1000);
    if(ret > 0)
        stat = true;
    memcpy(&mouseConf,&recv_buf[0],sizeof(MouseConfig));
    bufInit();
}

bool MouseComm::connTest(hid_device *mydev)
{
    bool stat = false;
    send_buf[2] = 0x06;
    hid_write(mydev,send_buf,65);
    int ret = hid_read_timeout(mydev, recv_buf,64,1000);
    if(ret > 0)
        stat = true;
    bufInit();
    return stat;
}

void MouseComm::bufInit()
{
    memset(recv_buf,0,sizeof(recv_buf));
    memset(send_buf,0,sizeof(send_buf));
    send_buf[0] = 0x00;
    send_buf[1] = 0xfe;
}
