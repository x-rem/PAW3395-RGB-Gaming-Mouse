#ifndef MYLABEL_H
#define MYLABEL_H

#include <QWidget>
#include <QHBoxLayout>
#include <QLabel>
#include <QPainter>
#include <QVariantAnimation>
#include <QEvent>
#include <functional>

class MyLabel : public QWidget
{
    Q_OBJECT
public:
    explicit MyLabel(QWidget *parent = nullptr);
    
    void setBgColor(QColor color);
    void setHoverBgColor(QColor color);
    void setTextColor(QColor color);
    void setText(QString text);
    void setRadius(qreal radius);
    void setClickCallback(const std::function<void()>& callback)
    {
        clickCallback = callback;
    }
    QLabel m_text;
protected:
    void paintEvent(QPaintEvent *event) override;
    void enterEvent(QEvent *event) override;
    void leaveEvent(QEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override
    {
        Q_UNUSED(event);
        if (clickCallback != nullptr) {
            // 当点击事件发生时，调用设置的函数
            clickCallback();
        }
    }
signals:
private:
    std::function<void()> clickCallback;
    QColor m_bgColor;
    QColor m_curBgColor;
    QColor m_hoverBgColor;
    
    
    
    QColor m_textColor;
    QColor m_curTextColor;
    QColor m_hoverTextColor;
    
    QFont m_font;
    
    QHBoxLayout m_baseLayout;
    qreal m_cornerRadius;
    QVariantAnimation m_bgColorAnimation;
    QVariantAnimation m_textAnimation;
};

#endif // MYLABEL_H
