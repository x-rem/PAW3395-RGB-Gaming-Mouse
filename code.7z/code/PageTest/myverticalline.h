#ifndef MYVERTICALLINE_H
#define MYVERTICALLINE_H

#include <QWidget>
#include <QPainter>
#include <QColor>
class MyVerticalLine : public QWidget
{
    Q_OBJECT
public:
    explicit MyVerticalLine(QWidget *parent = nullptr,QColor color = QColor(0,0,0));
protected:
    QColor m_color;
signals:
    
};

#endif // MYVERTICALLINE_H
