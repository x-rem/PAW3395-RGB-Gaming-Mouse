#include "mykeyeventfilter.h"
#include <QDebug>

MyKeyEventFilter::MyKeyEventFilter(QObject *parent)
    : QObject(parent)
{
}

bool MyKeyEventFilter::eventFilter(QObject *obj, QEvent *event)
{
    if (event->type() == QEvent::KeyPress) {
        QKeyEvent *keyEvent = static_cast<QKeyEvent *>(event);
        QLineEdit *lineEdit = qobject_cast<QLineEdit *>(obj);

        if (lineEdit) {
            QString keyText = getKeyText(keyEvent);

            if (!keyText.isEmpty()) {
                lineEdit->setText(keyText);
                return true; // 拦截事件
            } else {
                // 如果按下的不是允许的按键，清空 QLineEdit 或显示提示
                lineEdit->clear();
                return true; // 即使是无效按键也拦截，阻止默认行为
            }
        }
    }
    // 对于其他类型的事件，传递给默认事件处理器
    return QObject::eventFilter(obj, event);
}

QString MyKeyEventFilter::getKeyText(QKeyEvent *event)
{
    int key = event->key();
    QString keyText;

    // 1. ESC 键
    if (key == Qt::Key_Escape) {
        keyText = "ESC";
    }
    // 2. F1 - F12 键
    else if (key >= Qt::Key_F1 && key <= Qt::Key_F12) {
        keyText = QString("F%1").arg(key - Qt::Key_F1 + 1);
    }
    // 3. A - Z 键
    else if (key >= Qt::Key_A && key <= Qt::Key_Z) {
        keyText = QChar(key);
        if (!(event->modifiers() & Qt::ShiftModifier) && keyText.length() == 1) {
            keyText = keyText.toLower();
        }
    }
    // 4. 主键盘区域的 0 - 9 键
    else if (key >= Qt::Key_0 && key <= Qt::Key_9) {
        keyText = QChar(key);
    }
    else if (key == Qt::Key_Minus) {
        keyText = "-";
    } else if (key == Qt::Key_Equal) {
        if (event->modifiers() & Qt::ShiftModifier) {
            keyText = "+";
        } else {
            keyText = "=";
        }
    }

    return keyText;
}
