#ifndef PAGETEST_H
#define PAGETEST_H


#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <QVector>
#include <QStackedWidget>
#include <QPushButton>
#include <string>
#include <cstring>
#include "mylabel.h"
#include "mytitlebar.h"
#include "mysliderh.h"
#include "mousesliderbar.h"
#include "mousespeedpage.h"
#include "buttonsettingpage.h"
#include "rgbsettingpage.h"
#include "mouseconfig.h"
#include <QDebug>
#include "mousecomm.h"
#include <cstdint>
#include <QMap>
#include <QKeyEvent>
#include "hidapi.h"
QT_BEGIN_NAMESPACE
namespace Ui { class PageTest; }
QT_END_NAMESPACE

class PageTest : public QWidget
{
    Q_OBJECT
    
public:
    PageTest(QWidget *parent = nullptr);
    ~PageTest();
    
private:
    Ui::PageTest *ui;
    void switchPage(int i);
    
    QHBoxLayout* m_baseLayout;
    QVBoxLayout* m_rightLayout;
    QWidget* m_rightWidget;
    QStackedWidget* m_stackWidget;
    MouseSliderBar* sliderBar;
    MouseSpeedPage* m_speedPage;
    ButtonSettingPage* m_settingPage;
    RgbSettingPage* m_rgbPage;
    
    QWidget* m_btnWidget;
    QHBoxLayout* m_btnLayout;
    QPushButton* m_applyBtn;
    QPushButton* m_backBtn;
    
    
    MouseComm m_comm;
    QVector<std::string> devPathList;
    MouseConfig m_mouseCfg;
    hid_device* mydev;
    unsigned short vendorId = 0x48e;  // 目标设备 Vendor ID
    unsigned short productId = 0x56ef; // 目标设备 Product ID
    void initBg();
    void readCfg();
    bool chkDevExist();
    void reflushPage();
    
    void dpiFunc();
    void btnFunc();
    void rgbFunc();
    void applyFunc();
};
#endif // PAGETEST_H
