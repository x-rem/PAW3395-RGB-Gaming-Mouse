#ifndef COLORPICKERWIDGET_H
#define COLORPICKERWIDGET_H

#include <QWidget>
#include <QColor>
#include <QMouseEvent>
#include <QPoint>

class ColorPickerWidget : public QWidget
{
    Q_OBJECT

public:
    explicit ColorPickerWidget(QWidget *parent = nullptr);
    QSize minimumSizeHint() const override;
    QSize sizeHint() const override;

    // 对外暴露获取当前颜色的函数
    QColor currentColor() const;

    // 对外暴露设置当前颜色的函数
    void setCurrentColor(const QColor &color);

signals:
    // 颜色改变时发出的信号
    void colorChanged(const QColor &newColor);

protected:
    void paintEvent(QPaintEvent *event) override;
    void mousePressEvent(QMouseEvent *event) override;
    void mouseMoveEvent(QMouseEvent *event) override;
    void mouseReleaseEvent(QMouseEvent *event) override;

private:
    QColor m_currentColor;        // 存储当前选中的完整颜色 (HSV包含H, S, V)
    bool m_isHueDragging;         // 标志是否正在拖动色调条
    bool m_isSVDragging;          // 标志是否正在拖动饱和度/亮度区域
    QPoint m_selectedSVPoint;     // 存储饱和度/亮度区域的指示点位置

    // 计算饱和度/亮度区域的矩形
    QRect svRect() const;
    // 计算色调条区域的矩形
    QRect hueRect() const;

    // 根据鼠标Y坐标更新色调，并更新m_currentColor
    void updateHueFromMouseY(int mouseY);
    // 根据鼠标X,Y坐标更新饱和度/亮度，并更新m_currentColor
    void updateSVFromMouseXY(int mouseX, int mouseY);
    
};

#endif // COLORPICKERWIDGET_H
