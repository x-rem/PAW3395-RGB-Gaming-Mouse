#ifndef MYKEYEVENTFILTER_H
#define MYKEYEVENTFILTER_H

#include <QObject>
#include <QKeyEvent>
#include <QLineEdit>

class MyKeyEventFilter : public QObject
{
    Q_OBJECT

public:
    explicit MyKeyEventFilter(QObject *parent = nullptr);

protected:
    bool eventFilter(QObject *obj, QEvent *event) override;

private:
    QString getKeyText(QKeyEvent *event);
};

#endif // MYKEYEVENTFILTER_H
