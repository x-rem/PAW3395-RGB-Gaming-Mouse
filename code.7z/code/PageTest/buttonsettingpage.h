#ifndef BUTTONSETTINGPAGE_H
#define BUTTONSETTINGPAGE_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QComboBox>
#include <QLabel>
#include <QLineEdit>
#include "mykeyeventfilter.h"

class SettingPage : public QWidget
{
    Q_OBJECT
public:
    explicit SettingPage(QWidget *parent = nullptr);
    QLabel* m_label;
    QComboBox* m_settingCombo;
    QLineEdit* m_customEdit;
signals:
private:
    QHBoxLayout* m_baseLayout;
    MyKeyEventFilter *keyFilter; // 事件过滤器实例
};
class ButtonSettingPage : public QWidget
{
    Q_OBJECT
public:
    explicit ButtonSettingPage(QWidget *parent = nullptr);
    SettingPage* m_forwardPage;
    SettingPage* m_backPage;
    SettingPage* m_dpiPage;
signals:
private:
    
    QVBoxLayout* m_baseLayout;
    void initBg();
};

#endif // BUTTONSETTINGPAGE_H
