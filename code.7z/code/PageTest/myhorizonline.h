#ifndef MYHORIZONLINE_H
#define MYHORIZONLINE_H

#include <QWidget>

class MyHorizonLine : public QWidget
{
    Q_OBJECT
public:
    explicit MyHorizonLine(QWidget *parent = nullptr,QColor color = QColor(0,0,0));
protected:
    QColor m_color;
signals:
    
};

#endif // MYHORIZONLINE_H
