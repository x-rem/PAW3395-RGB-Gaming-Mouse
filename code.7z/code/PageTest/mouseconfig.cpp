#include "mouseconfig.h"

MouseConfig::MouseConfig()
{
    
}
