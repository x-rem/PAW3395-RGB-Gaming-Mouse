#ifndef RGBSETTINGPAGE_H
#define RGBSETTINGPAGE_H

#include <QWidget>
#include <QComboBox>
#include <QColorDialog>
#include <QLabel>
#include <mysliderh.h>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include "buttonsettingpage.h"
#include "colorpickerwidget.h"

class RgbSettingPage : public QWidget
{
    Q_OBJECT
public:
    SettingPage* m_modePage;
    SettingPage* m_speedPage;
    SettingPage* m_brightPage;
    explicit RgbSettingPage(QWidget *parent = nullptr);
    // 对外暴露获取当前颜色的函数
    QColor currentColor() const;

    // 对外暴露设置当前颜色的函数
    void setCurrentColor(const QColor &color);
signals:
private:
    
    ColorPickerWidget* m_colorPage;
    QVBoxLayout* m_baseLayout;
    
    
    void initBg();
};

#endif // RGBSETTINGPAGE_H
