#ifndef MYLINE_H
#define MYLINE_H

#include <QWidget>

class MyLine : public QWidget
{
    Q_OBJECT
public:
    explicit MyLine(QWidget *parent = nullptr,QColor color = QColor(0,0,0));
    void setSize(int width,int height)
    {
        setFixedHeight(height);
        setFixedWidth(width);
    }
    void setColor(QColor color)
    {
        m_color = color;
    }
signals:
private:
    QColor m_color;
};

#endif // MYLINE_H
