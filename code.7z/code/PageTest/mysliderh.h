#ifndef SLIDERWIDGET_H
#define SLIDERWIDGET_H
 
#include <QWidget>
#include <QMouseEvent>
 
class SliderWidget : public QWidget
{
    Q_OBJECT
public:
    explicit SliderWidget(int w, int h, QWidget *parent = 0);
 
    void setMaxVal(qreal val);
    void setMinVal(qreal val);
    void setVal(qreal val);
 
    qreal getCurVal() const;
    qreal getMinVal() const;
    qreal getMaxVal() const;
 
protected:
    void paintEvent(QPaintEvent *e);
    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent *event);
 
private:
    void getCurPoint(QMouseEvent *event);
 
signals:
    void sigPositonChange(qreal curVal);
 
private:
    QPoint m_curPoint;
    qreal m_maxVal;
    qreal m_minVal;
    qreal m_curVal;
};
 
#endif // SLIDERWIDGET_H
