#ifndef MOUSECOMM_H
#define MOUSECOMM_H

#include "mouseconfig.h"
#include "hidapi.h"


class MouseComm
{
public:
    MouseComm();
    bool modAll(const MouseConfig& mouseConf);
    
    bool modBtn(const MouseConfig& mouseConf,hid_device* mydev);
    bool modDpi(const MouseConfig& mouseConf,hid_device* mydev);
    bool modRgb(const MouseConfig& mouseConf,hid_device* mydev);
    void readCfg(MouseConfig& mouseConf,hid_device* mydev);
    bool connTest(hid_device* mydev);
private:
    void bufInit();
    unsigned char send_buf[65] = {0};
    //65的原因是一字节开头报告编号 每个包传输的第一个byte为写数据report ID，上、下位机必须一致。
    //但目前下位机没有设置report id 因此要让出一个字节
    unsigned char recv_buf[64] = {0};
};

#endif // MOUSECOMM_H
