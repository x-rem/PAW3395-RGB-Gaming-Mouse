#include "pagetest.h"
#include "ui_pagetest.h"
#include "myverticalline.h"
#include <iostream>
#include "myline.h"
#include <QMessageBox>
uint8_t getHidValueFromKeyName(const QString &keyName);
QString getKeyNameFromHidValue(uint8_t hidValue);
PageTest::PageTest(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::PageTest)
{
    ui->setupUi(this);
    mydev = NULL;
    m_baseLayout = new QHBoxLayout(this);
    m_rightWidget = new QWidget(this);
    m_rightLayout = new QVBoxLayout(m_rightWidget);
    sliderBar = new MouseSliderBar(this);
    
    
    MyLine* vLine = new MyLine(this,QColor("#e8e9eb"));
    vLine->setFixedWidth(2);
    MyLine* hLine = new MyLine(this,QColor("#e8e9eb"));
    hLine->setFixedHeight(2);
    m_stackWidget = new QStackedWidget(m_rightWidget);
    
    m_speedPage = new MouseSpeedPage(m_rightWidget);
    m_settingPage = new ButtonSettingPage(m_rightWidget);
    m_rgbPage = new RgbSettingPage(m_rightWidget);
    
    
    m_btnWidget = new QWidget(m_rightWidget);
    m_btnLayout = new QHBoxLayout(m_btnWidget);
    m_applyBtn = new QPushButton("应用",m_btnWidget);
    //m_backBtn = new QPushButton("返回",m_btnWidget);
    
    m_btnLayout->setContentsMargins(5,5,5,5);
    m_btnLayout->addStretch();
    m_btnLayout->addWidget(m_applyBtn);
    //m_btnLayout->addWidget(m_backBtn);
    
    m_btnWidget->setLayout(m_btnLayout);
    
    m_baseLayout->setContentsMargins(0,0,0,0);
    m_rightLayout->setContentsMargins(0,0,0,0);
    
    m_baseLayout->addWidget(sliderBar);
    sliderBar->setFixedWidth(300);
    m_baseLayout->addWidget(vLine);
    m_baseLayout->addWidget(m_rightWidget);
    
    
    
    m_stackWidget->addWidget(m_speedPage);
    m_stackWidget->addWidget(m_settingPage);
    m_stackWidget->addWidget(m_rgbPage);
    
    m_rightWidget->setLayout(m_rightLayout);
    m_rightLayout->addWidget(m_stackWidget);
    m_rightLayout->addWidget(hLine);
    m_rightLayout->addWidget(m_btnWidget);
    
    
    
    for(int i = 0;i<3;i++)
    {
        sliderBar->labelList[i]->setClickCallback([this, i]() {
            switchPage(i);  // 调用 switchPage 函数切换页面
        });
    }
    initBg();
    setLayout(m_baseLayout);
    connect(m_applyBtn,&QPushButton::clicked,this,PageTest::applyFunc);
    readCfg();
}


PageTest::~PageTest()
{
    delete ui;
}

void PageTest::switchPage(int i)
{
    if(m_stackWidget->count() >= (i-1))
    {
        m_stackWidget->setCurrentIndex(i);
    }
}

void PageTest::initBg()
{
    QPalette palette = this->palette();
    palette.setColor(QPalette::Window, QColor("#f1f5f8"));
    setAutoFillBackground(true);
    setPalette(palette);
}

void PageTest::readCfg()
{
    hid_device_info* infos =  hid_enumerate(vendorId, productId);
    for(hid_device_info* infop = infos;
        infop != NULL;
        infop = infop->next)
    {
        if(infop->interface_number == 0)
        {
            devPathList.append(std::string(infop->path));
        }
    }
    hid_free_enumeration(infos);
    
    if(devPathList.size() == 0)
    {
        QMessageBox::information(nullptr, "设备未找到", "没有找到设备", QMessageBox::Ok);
    }
    
    if(devPathList.size() != 0)
    {
        mydev = hid_open_path(devPathList[0].c_str());
        std::cout<<"pagetest: "<<mydev<<std::endl;
        if(mydev != NULL)
        {
            m_comm.readCfg(m_mouseCfg,mydev);
            reflushPage();
        } 
    }
    
}

bool PageTest::chkDevExist()
{
    return m_comm.connTest(mydev);
}

void PageTest::reflushPage()
{
    //dpi page
    uint16_t dpi1Nums = 0;
    uint16_t dpi2Nums = 0;
    uint16_t dpi3Nums = 0;
    
    dpi1Nums = (static_cast<uint16_t>(m_mouseCfg.dpi_slot1_high) << 8) | static_cast<uint16_t>(m_mouseCfg.dpi_slot1_low);
    dpi2Nums = (static_cast<uint16_t>(m_mouseCfg.dpi_slot2_high) << 8) | static_cast<uint16_t>(m_mouseCfg.dpi_slot2_low);
    dpi3Nums = (static_cast<uint16_t>(m_mouseCfg.dpi_slot3_high) << 8) | static_cast<uint16_t>(m_mouseCfg.dpi_slot3_low);
    
    
    m_speedPage->dpi1->setDpiNumLabelText((dpi1Nums+1)*50);
    m_speedPage->dpi2->setDpiNumLabelText((dpi2Nums+1)*50);
    m_speedPage->dpi3->setDpiNumLabelText((dpi3Nums+1)*50);
    
    
    //btn page
    std::cout<<"back key: "<<(int)m_mouseCfg.back_key_func<<std::endl;
    std::cout<<"forward key: "<<(int)m_mouseCfg.forward_key_func<<std::endl;
    std::cout<<"dpi key: "<<(int)m_mouseCfg.dpi_key_func<<std::endl;
    
    m_settingPage->m_backPage->m_settingCombo->setCurrentIndex(0);
    m_settingPage->m_forwardPage->m_settingCombo->setCurrentIndex(0);
    m_settingPage->m_dpiPage->m_settingCombo->setCurrentIndex(0);
    
    if(m_mouseCfg.back_key_func != 0xff)
    {
        m_settingPage->m_backPage->m_settingCombo->setCurrentIndex(1);
        m_settingPage->m_backPage->m_customEdit->setText(getKeyNameFromHidValue(m_mouseCfg.back_key_func));
    }
    if(m_mouseCfg.forward_key_func != 0xff)
    {
        m_settingPage->m_forwardPage->m_settingCombo->setCurrentIndex(1);
        m_settingPage->m_forwardPage->m_customEdit->setText(getKeyNameFromHidValue(m_mouseCfg.forward_key_func));
    }
    if(m_mouseCfg.dpi_key_func != 0xff)
    {
        m_settingPage->m_dpiPage->m_settingCombo->setCurrentIndex(1);
        m_settingPage->m_dpiPage->m_customEdit->setText(getKeyNameFromHidValue(m_mouseCfg.dpi_key_func));
    }
    
    //rgb page
    QColor color(m_mouseCfg.rgb_color_r,m_mouseCfg.rgb_color_g,m_mouseCfg.rgb_color_b);
    m_rgbPage->setCurrentColor(color);
    int modeIndex = m_mouseCfg.rgb_mode;
    m_rgbPage->m_modePage->m_settingCombo->setCurrentIndex(modeIndex);
    
    
    float baseBright = m_mouseCfg.rgb_bright;
    float baseSpeed = m_mouseCfg.rgb_speed;
    
    int speedIndex = 0;
    int brightIndex = 0;
    if(modeIndex == 2)
    {
        speedIndex = baseSpeed * 100;
    }
    else
    {
        speedIndex = baseSpeed * 10;
    }
    brightIndex = baseBright*10 -1;
    speedIndex -= 1;
    m_rgbPage->m_speedPage->m_settingCombo->setCurrentIndex(speedIndex);
    m_rgbPage->m_brightPage->m_settingCombo->setCurrentIndex(brightIndex);
}

void PageTest::dpiFunc()
{
    uint16_t dpi1 = m_speedPage->dpi1->m_dpiNum / 50 - 1;
    uint16_t dpi2 = m_speedPage->dpi2->m_dpiNum / 50 - 1;
    uint16_t dpi3 = m_speedPage->dpi3->m_dpiNum / 50 - 1;
    
    m_mouseCfg.dpi_slot1_high = (dpi1 >> 8) & 0xFF;  // 高8位
    m_mouseCfg.dpi_slot1_low = dpi1 & 0xFF;  // 低8位
    
    m_mouseCfg.dpi_slot2_high = (dpi2 >> 8) & 0xFF;  // 高8位
    m_mouseCfg.dpi_slot2_low = dpi2 & 0xFF;  // 低8位
    
    m_mouseCfg.dpi_slot3_high = (dpi3 >> 8) & 0xFF;  // 高8位
    m_mouseCfg.dpi_slot3_low = dpi3 & 0xFF;  // 低8位
    std::cout<<"stat: "<<m_comm.modDpi(m_mouseCfg,mydev)<<std::endl;
}

void PageTest::btnFunc()
{
    uint8_t backKeyHidValue = 0xff;
    uint8_t forwardKeyHidValue = 0xff;
    uint8_t dpiKeyHidValue = 0xff;
    
    QString forwardKeyName = m_settingPage->m_forwardPage->m_customEdit->text();
    QString dpiKeyName = m_settingPage->m_dpiPage->m_customEdit->text();
    QString backKeyName = m_settingPage->m_backPage->m_customEdit->text();
    
    if(m_settingPage->m_backPage->m_settingCombo->currentIndex() != 0)
        backKeyHidValue = getHidValueFromKeyName(backKeyName);
    
    
    if(m_settingPage->m_forwardPage->m_settingCombo->currentIndex() != 0)
        forwardKeyHidValue = getHidValueFromKeyName(forwardKeyName);
    
    
    if(m_settingPage->m_dpiPage->m_settingCombo->currentIndex() != 0)
        dpiKeyHidValue = getHidValueFromKeyName(dpiKeyName);
    
    m_mouseCfg.back_key_func = backKeyHidValue;
    m_mouseCfg.forward_key_func = forwardKeyHidValue;
    m_mouseCfg.dpi_key_func = dpiKeyHidValue;
    
    
    std::cout<<"mod btn: "<<m_comm.modBtn(m_mouseCfg,mydev)<<std::endl;
}

void PageTest::rgbFunc()
{
    QColor color = m_rgbPage->currentColor();
    uint8_t modeIndex = m_rgbPage->m_modePage->m_settingCombo->currentIndex();
    int speedIndex = m_rgbPage->m_speedPage->m_settingCombo->currentIndex();
    int brightIndex = m_rgbPage->m_brightPage->m_settingCombo->currentIndex();
    
    float rgb_bright = (brightIndex+1) /(float)10;
    float breath_speed = (speedIndex+1) / (float)100;
    float chroma_speed = (speedIndex+1) / (float)10;
    std::cout<<"r: "<<color.red()<<",g: "<<color.green()<<",b: "<<color.blue()<<std::endl;
    std::cout<<"modeIndex: "<<(int)modeIndex<<std::endl;
    std::cout<<"breath_speed: "<<breath_speed<<std::endl;
    std::cout<<"chroma_speed: "<<chroma_speed<<std::endl;
    std::cout<<"rgb_bright: "<<rgb_bright<<std::endl;
    
    m_mouseCfg.rgb_mode = modeIndex;
    m_mouseCfg.rgb_bright = rgb_bright;
    m_mouseCfg.rgb_color_r = color.red();
    m_mouseCfg.rgb_color_g = color.green();
    m_mouseCfg.rgb_color_b = color.blue();
    if(modeIndex == 2)
    {
        m_mouseCfg.rgb_speed = breath_speed;
    }
    else if(modeIndex == 3)
    {
        m_mouseCfg.rgb_speed = chroma_speed;
    }
    std::cout<<"rgb stat: "<<m_comm.modRgb(m_mouseCfg,mydev)<<std::endl;
}
void PageTest::applyFunc()
{
    if(devPathList.size() == 0)
    {
        QMessageBox::information(nullptr, "设备未找到", "没有找到设备", QMessageBox::Ok);
        return;
    }
    if(!chkDevExist())
    {
        return;
    }
    
    int pageIndex = m_stackWidget->currentIndex();
    switch(pageIndex)
    {
    case 0:
    {
        dpiFunc();
        break;
    }
    case 1:
    {
        btnFunc();
        break;
    }
    case 2:
    {
        rgbFunc();
        break;
    }
    default:
        break;
    }

}



static const QMap<QString, int> keyNameToQtKeyMap = {
    {"ESC", Qt::Key_Escape},
    {"F1", Qt::Key_F1},
    {"F2", Qt::Key_F2},
    {"F3", Qt::Key_F3},
    {"F4", Qt::Key_F4},
    {"F5", Qt::Key_F5},
    {"F6", Qt::Key_F6},
    {"F7", Qt::Key_F7},
    {"F8", Qt::Key_F8},
    {"F9", Qt::Key_F9},
    {"F10", Qt::Key_F10},
    {"F11", Qt::Key_F11},
    {"F12", Qt::Key_F12},
    {"A", Qt::Key_A}, {"a", Qt::Key_A},
    {"B", Qt::Key_B}, {"b", Qt::Key_B},
    {"C", Qt::Key_C}, {"c", Qt::Key_C},
    {"D", Qt::Key_D}, {"d", Qt::Key_D},
    {"E", Qt::Key_E}, {"e", Qt::Key_E},
    {"F", Qt::Key_F}, {"f", Qt::Key_F},
    {"G", Qt::Key_G}, {"g", Qt::Key_G},
    {"H", Qt::Key_H}, {"h", Qt::Key_H},
    {"I", Qt::Key_I}, {"i", Qt::Key_I},
    {"J", Qt::Key_J}, {"j", Qt::Key_J},
    {"K", Qt::Key_K}, {"k", Qt::Key_K},
    {"L", Qt::Key_L}, {"l", Qt::Key_L},
    {"M", Qt::Key_M}, {"m", Qt::Key_M},
    {"N", Qt::Key_N}, {"n", Qt::Key_N},
    {"O", Qt::Key_O}, {"o", Qt::Key_O},
    {"P", Qt::Key_P}, {"p", Qt::Key_P},
    {"Q", Qt::Key_Q}, {"q", Qt::Key_Q},
    {"R", Qt::Key_R}, {"r", Qt::Key_R},
    {"S", Qt::Key_S}, {"s", Qt::Key_S},
    {"T", Qt::Key_T}, {"t", Qt::Key_T},
    {"U", Qt::Key_U}, {"u", Qt::Key_U},
    {"V", Qt::Key_V}, {"v", Qt::Key_V},
    {"W", Qt::Key_W}, {"w", Qt::Key_W},
    {"X", Qt::Key_X}, {"x", Qt::Key_X},
    {"Y", Qt::Key_Y}, {"y", Qt::Key_Y},
    {"Z", Qt::Key_Z}, {"z", Qt::Key_Z},
    {"0", Qt::Key_0},
    {"1", Qt::Key_1},
    {"2", Qt::Key_2},
    {"3", Qt::Key_3},
    {"4", Qt::Key_4},
    {"5", Qt::Key_5},
    {"6", Qt::Key_6},
    {"7", Qt::Key_7},
    {"8", Qt::Key_8},
    {"9", Qt::Key_9},
    {"-", Qt::Key_Minus},
    {"_", Qt::Key_Minus}, // Shift + -
    {"=", Qt::Key_Equal},
    {"+", Qt::Key_Equal}  // Shift + =
};

// 另一个映射：从 Qt::Key 到 HID 键值 uint8_t
static const QMap<int, uint8_t> qtKeyToHidValueMap = {
    {Qt::Key_Escape, 0x29},
    {Qt::Key_F1, 0x3A},
    {Qt::Key_F2, 0x3B},
    {Qt::Key_F3, 0x3C},
    {Qt::Key_F4, 0x3D},
    {Qt::Key_F5, 0x3E},
    {Qt::Key_F6, 0x3F},
    {Qt::Key_F7, 0x40},
    {Qt::Key_F8, 0x41},
    {Qt::Key_F9, 0x42},
    {Qt::Key_F10, 0x43},
    {Qt::Key_F11, 0x44},
    {Qt::Key_F12, 0x45},
    {Qt::Key_A, 0x04},
    {Qt::Key_B, 0x05},
    {Qt::Key_C, 0x06},
    {Qt::Key_D, 0x07},
    {Qt::Key_E, 0x08},
    {Qt::Key_F, 0x09},
    {Qt::Key_G, 0x0A},
    {Qt::Key_H, 0x0B},
    {Qt::Key_I, 0x0C},
    {Qt::Key_J, 0x0D},
    {Qt::Key_K, 0x0E},
    {Qt::Key_L, 0x0F},
    {Qt::Key_M, 0x10},
    {Qt::Key_N, 0x11},
    {Qt::Key_O, 0x12},
    {Qt::Key_P, 0x13},
    {Qt::Key_Q, 0x14},
    {Qt::Key_R, 0x15},
    {Qt::Key_S, 0x16},
    {Qt::Key_T, 0x17},
    {Qt::Key_U, 0x18},
    {Qt::Key_V, 0x19},
    {Qt::Key_W, 0x1A},
    {Qt::Key_X, 0x1B},
    {Qt::Key_Y, 0x1C},
    {Qt::Key_Z, 0x1D},
    {Qt::Key_0, 0x27},
    {Qt::Key_1, 0x1E},
    {Qt::Key_2, 0x1F},
    {Qt::Key_3, 0x20},
    {Qt::Key_4, 0x21},
    {Qt::Key_5, 0x22},
    {Qt::Key_6, 0x23},
    {Qt::Key_7, 0x24},
    {Qt::Key_8, 0x25},
    {Qt::Key_9, 0x26},
    {Qt::Key_Minus, 0x2D},
    {Qt::Key_Equal, 0x2E}
};

/**
 * @brief 根据按键名称字符串获取对应的 HID 键值。
 * @param keyName 从 QLineEdit 中获取的按键名称字符串（例如 "ESC", "A", "a", "+", "="）。
 * @return 对应的 HID 键值（uint8_t 类型），如果未找到则返回 0。
 */
uint8_t getHidValueFromKeyName(const QString &keyName)
{
    // 查找按键名称对应的 Qt::Key 值
    if (keyNameToQtKeyMap.contains(keyName)) {
        int qtKey = keyNameToQtKeyMap.value(keyName);

        // 使用 Qt::Key 值查找对应的 HID 值
        if (qtKeyToHidValueMap.contains(qtKey)) {
            return qtKeyToHidValueMap.value(qtKey);
        }
    }
    return 0xff; // 如果按键名称不在映射表中，或没有对应的 HID 值，则返回 0
}

QString getKeyNameFromHidValue(uint8_t hidValue)
{
    // 反向查找：从 HID 键值找到对应的 Qt::Key 值
    for (auto it = qtKeyToHidValueMap.begin(); it != qtKeyToHidValueMap.end(); ++it) {
        if (it.value() == hidValue) {
            // 找到匹配的 HID 键值后，返回对应的按键名称
            return keyNameToQtKeyMap.key(it.key());
        }
    }
    return ""; // 如果没有找到匹配的 HID 键值，则返回空字符串
}
