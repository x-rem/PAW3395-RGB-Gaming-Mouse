#include "buttonsettingpage.h"

ButtonSettingPage::ButtonSettingPage(QWidget *parent) : QWidget(parent)
{
    m_forwardPage = new SettingPage(this);
    m_backPage = new SettingPage(this);
    m_dpiPage = new SettingPage(this);
    m_baseLayout = new QVBoxLayout(this);
    m_baseLayout->setContentsMargins(0,0,0,0);
    
    m_forwardPage->m_label->setText("前进键:");
    m_backPage->m_label->setText("后退键:");
    m_dpiPage->m_label->setText("DPI键:");
    
    m_forwardPage->m_settingCombo->addItem("默认");
    m_forwardPage->m_settingCombo->addItem("自定义");
    
    m_backPage->m_settingCombo->addItem("默认");
    m_backPage->m_settingCombo->addItem("自定义");
    
    m_dpiPage->m_settingCombo->addItem("默认");
    m_dpiPage->m_settingCombo->addItem("自定义");
    
    m_baseLayout->addStretch();
    m_baseLayout->addWidget(m_forwardPage);
    m_baseLayout->addWidget(m_backPage);
    m_baseLayout->addWidget(m_dpiPage);
    m_baseLayout->addStretch();
    
    setLayout(m_baseLayout);
    initBg();
}

void ButtonSettingPage::initBg()
{
    QPalette palette = this->palette();
    palette.setColor(QPalette::Window, QColor("#f1f5f8"));
    setAutoFillBackground(true);
    setPalette(palette);
}

SettingPage::SettingPage(QWidget *parent) : QWidget(parent)
{
    m_baseLayout = new QHBoxLayout(this);
    m_baseLayout->setContentsMargins(0,5,0,5);
    m_label = new QLabel(this);
    m_customEdit = new QLineEdit(this);
    m_settingCombo = new QComboBox(this);
    keyFilter = new MyKeyEventFilter(this);
    m_customEdit->installEventFilter(keyFilter);
    m_baseLayout->addWidget(m_label);
    m_baseLayout->addWidget(m_settingCombo);
    m_baseLayout->addWidget(m_customEdit);
    m_customEdit->setFixedWidth(50);
    m_baseLayout->addStretch();
    setLayout(m_baseLayout);
}
