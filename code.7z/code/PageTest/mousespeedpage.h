#ifndef MOUSESPEEDPAGE_H
#define MOUSESPEEDPAGE_H

#include <QWidget>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include "mysliderh.h"
#include <QVector>
#include <QLabel>
#include <QColor>
#include <cstdint>
class DpiPage : public QWidget
{
    Q_OBJECT
public:
    explicit DpiPage(QWidget *parent = nullptr);
    QVBoxLayout* m_baseLayout;
    QHBoxLayout* m_dpiLayout;
    QWidget* m_dpiTextWidget;
    QLabel* m_dpiTextLabel;
    QLabel* m_dpiNumLabel;
    SliderWidget* m_slider;
    
    uint16_t m_dpiNum;
    void setDpiNumLabelText(uint16_t dpi);
private:
    void setDpiLabelNum(qreal curVal);
};
class MouseSpeedPage : public QWidget
{
    Q_OBJECT
public:
    explicit MouseSpeedPage(QWidget *parent = nullptr);
    DpiPage* dpi1;
    DpiPage* dpi2;
    DpiPage* dpi3;
signals:
private:
    void initBg();
    QVBoxLayout* m_baseLayout;
};

#endif // MOUSESPEEDPAGE_H
