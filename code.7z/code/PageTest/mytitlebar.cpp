#include "mytitlebar.h"
#include <QDebug>
#include <QPainter>
#include <QStyle>
#include <QApplication>
#include <QMouseEvent>
#include <QGraphicsDropShadowEffect>
MyTitleBar::MyTitleBar(QWidget *parent,QColor color) : QWidget(parent)
{
    setFixedHeight(30);  // 给定默认高度
    pWidget = parent;
    m_color = color;
    
    // 布局
    QHBoxLayout *layout = new QHBoxLayout(this);
    layout->setContentsMargins(5, 0, 5, 0);  // 设置边距
    initTitle();
    initBtn();
    m_leftButtonPressed = false;
    

    // 将控件添加到布局
    layout->addWidget(m_titleWidget);
    layout->addStretch();  // 将按钮推到右侧
    layout->addWidget(m_minimizeButton);
    layout->addWidget(m_closeButton);

    

    // 设置背景颜色
    setAttribute(Qt::WA_StyledBackground, true);
    QPalette palette = this->palette();
    palette.setColor(QPalette::Window, m_color); 
    setAutoFillBackground(true);
    setPalette(palette);

}

// 绘制背景颜色
void MyTitleBar::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.fillRect(this->rect().adjusted(0, 0, 0, -1), m_color);
}

void MyTitleBar::setHeight(int height)
{
    setFixedHeight(height);
}
void MyTitleBar::setTitle(QString title)
{
    m_titleLabel->setText(title);
}

void MyTitleBar::setTitleSize(const int& size)
{
    QFont font = m_titleLabel->font();
    font.setPointSize(size);
    m_titleLabel->setFont(font);
    update();
}

void MyTitleBar::setTitleColor(const QColor &color)
{
    QPalette palette = m_titleLabel->palette();
    palette.setColor(QPalette::WindowText,color);
    m_titleLabel->setPalette(palette);
    update();
}

// 最小化窗口
void MyTitleBar::onClickMinimize()
{
    emit minWin();
}

// 最大化/恢复窗口
void MyTitleBar::onClickMaximizeRestore()
{
//    if (!pWidget) return;

//    if (pWidget->isMaximized())
//    {
//        m_maximizeButton->setIcon(QApplication::style()->standardIcon(QStyle::SP_TitleBarMaxButton));
//        emit normalWin();
//    }
//    else
//    {
//        m_maximizeButton->setIcon(QApplication::style()->standardIcon(QStyle::SP_TitleBarNormalButton));
//        emit maxWin();
//    }
}

// 关闭窗口
void MyTitleBar::onClickClose()
{
    emit closeWin();
}

void MyTitleBar::initShadow()
{
    QGraphicsDropShadowEffect* shadow = new QGraphicsDropShadowEffect(this);
    shadow->setOffset(0, 0);
    shadow->setColor(Qt::black);
    shadow->setBlurRadius(10);
    this->setGraphicsEffect(shadow);
}

void MyTitleBar::initTitle()
{
    //初始化标题字体
    QFont titleFont;
    titleFont.setFamily("Segoe UI");
    titleFont.setBold(0);
    
    //初始化标题的widget
    m_titleWidget = new QWidget(this);
    m_titleLayout = new QHBoxLayout(m_titleWidget);
    m_titleLayout->setContentsMargins(20, 0, 5, 0);  // 设置边距
    m_titleWidget->setLayout(m_titleLayout);
    
    //初始化默认标题内容
    // 标题（可选）
    m_titleLabel = new QLabel("My Custom Title");
    m_titleLayout->addWidget(m_titleLabel);
    m_titleLabel->setFont(titleFont);
}

void MyTitleBar::initBtn()
{
    // 最小化按钮
    m_minimizeButton = new QPushButton(this);
    m_minimizeButton->setIcon(QApplication::style()->standardIcon(QStyle::SP_TitleBarMinButton));
    m_minimizeButton->setFixedSize(25, 25);
    m_minimizeButton->setStyleSheet("QPushButton { border: none; background: transparent; }"
                                   "QPushButton:hover { background: #ededed; }");


    // 关闭按钮
    m_closeButton = new QPushButton(this);
    m_closeButton->setIcon(QApplication::style()->standardIcon(QStyle::SP_TitleBarCloseButton));
    m_closeButton->setFixedSize(25, 25);
    m_closeButton->setStyleSheet("QPushButton { border: none; background: transparent; }"
                                "QPushButton:hover { background: #ff0000; }");  // 鼠标悬停变红
    
    // 连接按钮信号
    connect(m_minimizeButton, &QPushButton::clicked, this, &MyTitleBar::onClickMinimize);
    connect(m_closeButton, &QPushButton::clicked, this, &MyTitleBar::onClickClose);
}

// 支持窗口拖动
void MyTitleBar::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton && parentWidget())
    {
        m_leftButtonPressed = true;
        m_dragStartPosition = event->globalPos() - pWidget->frameGeometry().topLeft();
        event->accept();
    }
}

void MyTitleBar::mouseReleaseEvent(QMouseEvent *event)
{
    // 鼠标左键释放
    if (event->button() == Qt::LeftButton)
    {
        // 记录鼠标状态
        m_leftButtonPressed = false;
    }
}

void MyTitleBar::mouseMoveEvent(QMouseEvent *event)
{
    if (pWidget->isMaximized())
    {
        return;
    }
    if (event->buttons() & Qt::LeftButton && parentWidget() && m_leftButtonPressed)
    {
        pWidget->move(event->globalPos() - m_dragStartPosition);
        event->accept();
    }
}

