#ifndef MOUSESLIDERBAR_H
#define MOUSESLIDERBAR_H

#include <QWidget>
#include <QVBoxLayout>
#include <QVector>
#include "mylabel.h"

QT_BEGIN_NAMESPACE
class MouseSliderBar : public QWidget
{
    Q_OBJECT
public:
    explicit MouseSliderBar(QWidget *parent = nullptr);
    QVector<MyLabel*> labelList;
    QColor m_bgColor;
signals:
private:
    QVBoxLayout* m_pVlayout;
    void initBg();
    void initLayout();
    void initLabel();
};

#endif // MOUSESLIDERBAR_H
