#include "myslidebar.h"

MySlideBar::MySlideBar(QWidget *parent) : QWidget(parent)
{
    
}
