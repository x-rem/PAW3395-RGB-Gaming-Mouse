#include "rgbsettingpage.h"

RgbSettingPage::RgbSettingPage(QWidget *parent) : QWidget(parent)
{
    m_modePage = new SettingPage(this);
    m_speedPage = new SettingPage(this);
    m_brightPage = new SettingPage(this);
    m_colorPage = new ColorPickerWidget(this);
    
    m_modePage->m_label->setText("灯光模式:");
    m_speedPage->m_label->setText("速度");
    m_brightPage->m_label->setText("亮度");
     
    

    m_modePage->m_settingCombo->addItem("关闭");
    m_modePage->m_settingCombo->addItem("常亮");
    m_modePage->m_settingCombo->addItem("呼吸");
    m_modePage->m_settingCombo->addItem("炫彩");
    

    for(int i = 1;i<=10;i++)
    {
        m_speedPage->m_settingCombo->addItem(QString::number(i));
        m_brightPage->m_settingCombo->addItem(QString::number(i));
    }
    
    
    
    m_baseLayout = new QVBoxLayout(this);
    m_baseLayout->setContentsMargins(0,0,0,0);
    
    m_baseLayout->addStretch();
    m_baseLayout->addWidget(m_colorPage);
    m_baseLayout->addWidget(m_modePage);
    m_baseLayout->addWidget(m_speedPage);
    m_baseLayout->addWidget(m_brightPage);
    m_baseLayout->addStretch();
    
    
    
    setLayout(m_baseLayout);
    initBg();
}

QColor RgbSettingPage::currentColor() const
{
    return m_colorPage->currentColor();
}

void RgbSettingPage::setCurrentColor(const QColor &color)
{
    m_colorPage->setCurrentColor(color);
}

void RgbSettingPage::initBg()
{
    QPalette palette = this->palette();
    palette.setColor(QPalette::Window, QColor("#f1f5f8"));
    setAutoFillBackground(true);
    setPalette(palette);
}
