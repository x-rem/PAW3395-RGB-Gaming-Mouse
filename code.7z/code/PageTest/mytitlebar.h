#ifndef MYTITLEBAR_H
#define MYTITLEBAR_H

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QHBoxLayout> // 需要包含
#include <QString>
class MyTitleBar : public QWidget
{
    Q_OBJECT

public:
    explicit MyTitleBar(QWidget *parent = nullptr,QColor color = QColor(0,0,0));
    void setHeight(int height);
    void setTitle(QString title);
    void setTitleSize(const int& size);
    void setTitleColor(const QColor& color);
signals:
    void closeWin();
    void maxWin();
    void normalWin();
    void minWin();
protected:
    virtual void paintEvent(QPaintEvent *event) override;
    virtual void mousePressEvent(QMouseEvent *event) override;
    virtual void mouseReleaseEvent(QMouseEvent *event);
    virtual void mouseMoveEvent(QMouseEvent *event) override;
private slots:
    void onClickMinimize();
    void onClickMaximizeRestore();
    void onClickClose();

private:
    QColor m_color;
    QPoint m_dragStartPosition;  // 用于窗口拖动
    QPushButton *m_minimizeButton;
    QPushButton *m_closeButton;
    QLabel *m_titleLabel;
    QWidget* m_titleWidget;
    QWidget* pWidget;
    QHBoxLayout* m_titleLayout;
    bool m_leftButtonPressed;//鼠标左键按下标记
    void initShadow();
    void initTitle();
    void initBtn();
};
#endif // MYTITLEBAR_H
