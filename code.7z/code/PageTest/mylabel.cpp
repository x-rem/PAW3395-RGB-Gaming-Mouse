#include "mylabel.h"
#include <QDebug>
MyLabel::MyLabel(QWidget *parent) : QWidget(parent)
{
    m_font.setFamily("Segoe UI");
    m_font.setPixelSize(24);
    m_font.setBold(0);
    m_baseLayout.setContentsMargins(5,5,5,5);
    m_baseLayout.addStretch();
    m_baseLayout.addWidget(&m_text);
    m_baseLayout.addStretch();
    this->setFont(m_font);
    m_text.setFont(m_font);
    this->setLayout(&m_baseLayout);

    m_bgColor = QColor("#ffffff"); // 设置默认背景颜色
    m_curBgColor = m_bgColor; // 保存原始背景颜色
    m_hoverBgColor = QColor(60, 180, 230);
    
    m_textColor = QColor("#000000");
    m_curTextColor = m_textColor;
    m_hoverTextColor = QColor("#ffffff");
    
    
    m_bgColorAnimation.setDuration(125);
    m_textAnimation.setDuration(125);
    m_bgColorAnimation.setEasingCurve(QEasingCurve::Linear); // 动画缓动曲线
    m_textAnimation.setEasingCurve(QEasingCurve::Linear);
    
    connect(&m_bgColorAnimation, &QVariantAnimation::valueChanged, this, [this](const QVariant &value){
        m_curBgColor = value.value<QColor>(); // 动画更新边框颜色
        update(); // 触发重绘
    });
    
    connect(&m_textAnimation, &QVariantAnimation::valueChanged, this, [this](const QVariant &value){
        m_curTextColor = value.value<QColor>(); // 动画更新边框颜色
        update(); // 触发重绘
    });
    setAttribute(Qt::WA_StyledBackground, true);
}

void MyLabel::setBgColor(QColor color)
{
    m_bgColor = color;
    m_curBgColor = color;
    update();
}

void MyLabel::setHoverBgColor(QColor color)
{
    m_hoverBgColor = color;
}

void MyLabel::setTextColor(QColor color)
{
    QPalette palette = m_text.palette();
    palette.setColor(QPalette::WindowText, color);  // 设置文字颜色为红色
    m_text.setPalette(palette);
    update();
}

void MyLabel::setText(QString text)
{
    m_text.setText(text);
}

void MyLabel::setRadius(qreal radius)
{
    m_cornerRadius = radius;
    update();
}


void MyLabel::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);
    
    QPainter painter(this);
    painter.setRenderHint(QPainter::Antialiasing); // 用于更平滑的圆角
    painter.setBrush(m_curBgColor);
    painter.setPen(Qt::NoPen); // 背景无边框
    if (m_cornerRadius > 0) {
        painter.drawRoundedRect(rect(), m_cornerRadius, m_cornerRadius);
    } else {
        painter.drawRect(rect());
    }
    
    QPalette textPa = m_text.palette();
    textPa.setColor(QPalette::WindowText, m_curTextColor);  // 设置文字颜色
    m_text.setPalette(textPa);
}


void MyLabel::enterEvent(QEvent *event)
{
    Q_UNUSED(event);

    // 停止所有正在运行的动画
    if (m_bgColorAnimation.state() == QAbstractAnimation::Running) {
        m_bgColorAnimation.stop();
    }

    // 启动颜色动画
    m_bgColorAnimation.setStartValue(m_bgColor);
    m_bgColorAnimation.setEndValue(m_hoverBgColor); // 动画到目标颜色
    m_bgColorAnimation.start();
    
    
    m_textAnimation.setStartValue(m_textColor);
    m_textAnimation.setEndValue(m_hoverTextColor); // 动画到目标颜色
    m_textAnimation.start();
}

void MyLabel::leaveEvent(QEvent *event)
{
    Q_UNUSED(event);

    // 停止所有正在运行的动画
    if (m_bgColorAnimation.state() == QAbstractAnimation::Running) {
        m_bgColorAnimation.stop();
    }

    // 启动颜色动画
    m_bgColorAnimation.setStartValue(m_hoverBgColor);
    m_bgColorAnimation.setEndValue(m_bgColor); // 动画回原本颜色
    m_bgColorAnimation.start();
    
    
    m_textAnimation.setStartValue(m_hoverTextColor);
    m_textAnimation.setEndValue(m_textColor); // 动画到目标颜色
    m_textAnimation.start();
}
