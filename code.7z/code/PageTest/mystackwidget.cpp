#include "mystackwidget.h"

MyStackWidget::MyStackWidget(QWidget *parent) : QWidget(parent)
{
    connect(&m_animate, &QVariantAnimation::valueChanged, this, [this](const QVariant &value){
        m_curBgColor = value.value<QColor>(); // 动画更新边框颜色
        update(); // 触发重绘
    });
}

void MyStackWidget::next()
{
    if(isAnimation)
    {
        return;
    }
    isAnimation = true;
    
}
