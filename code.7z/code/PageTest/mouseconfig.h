#ifndef MOUSECONFIG_H
#define MOUSECONFIG_H

#include <QtGlobal>
#include <cstdint>
#include <iostream>

class MouseConfig
{
public:
    MouseConfig(); 
    uint8_t dpi_slot;
	uint8_t dpi_key_func;//if it's 0xff,that means use base function,other is keyboard function
	uint8_t forward_key_func;
	uint8_t back_key_func;
    
	uint8_t dpi_num;//max 3
	uint8_t dpi_reverse;
	uint8_t dpi_slot1_high;
	uint8_t dpi_slot1_low;
	uint8_t dpi_slot2_high;
	uint8_t dpi_slot2_low;
	uint8_t dpi_slot3_high;
	uint8_t dpi_slot3_low;
    
	uint8_t rgb_mode;
	uint8_t rgb_color_r;
	uint8_t rgb_color_g;
	uint8_t rgb_color_b;
	
	float rgb_bright;
	float rgb_speed;
    void print() const {
        std::cout << "dpi_slot: " << (int)dpi_slot << std::endl;
        std::cout << "dpi_key_func: " << (int)dpi_key_func << std::endl;
        std::cout << "forward_key_func: " << (int)forward_key_func << std::endl;
        std::cout << "back_key_func: " << (int)back_key_func << std::endl;
        
        std::cout << "dpi_num: " << (int)dpi_num << std::endl;
        std::cout << "dpi_reverse: " << (int)dpi_reverse << std::endl;
        
        std::cout << "dpi_slot1_high: " << (int)dpi_slot1_high << std::endl;
        std::cout << "dpi_slot1_low: " << (int)dpi_slot1_low << std::endl;
        std::cout << "dpi_slot2_high: " << (int)dpi_slot2_high << std::endl;
        std::cout << "dpi_slot2_low: " << (int)dpi_slot2_low << std::endl;
        std::cout << "dpi_slot3_high: " << (int)dpi_slot3_high << std::endl;
        std::cout << "dpi_slot3_low: " << (int)dpi_slot3_low << std::endl;
        
        std::cout << "rgb_mode: " << (int)rgb_mode << std::endl;
        std::cout << "rgb_color_r: " << (int)rgb_color_r << std::endl;
        std::cout << "rgb_color_g: " << (int)rgb_color_g << std::endl;
        std::cout << "rgb_color_b: " << (int)rgb_color_b << std::endl;
        
        std::cout << "rgb_bright: " << rgb_bright << std::endl;
        std::cout << "rgb_speed: " << rgb_speed << std::endl;
    }
};

#endif // MOUSECONFIG_H
