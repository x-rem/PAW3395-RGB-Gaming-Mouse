#ifndef MYSTACKWIDGET_H
#define MYSTACKWIDGET_H

#include <QWidget>
#include <QStackedWidget>
#include <QPropertyAnimation>
class MyStackWidget : public QStackedWidget
{
    Q_OBJECT
public:
    explicit MyStackWidget(QWidget *parent = nullptr);
    void changePage(int i);
signals:
private:
    bool isAnimation = false;
    QPropertyAnimation m_animate;
    int curPos;
    void next();
    void back();
};

#endif // MYSTACKWIDGET_H
