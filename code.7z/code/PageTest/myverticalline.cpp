#include "myverticalline.h"



MyVerticalLine::MyVerticalLine(QWidget *parent, QColor color): QWidget(parent)
{
    m_color = color;
    setFixedWidth(2);
    setAttribute(Qt::WA_StyledBackground, true);
    QPalette palette = this->palette();
    palette.setColor(QPalette::Window, m_color); 
    setAutoFillBackground(true);
    setPalette(palette);
}
