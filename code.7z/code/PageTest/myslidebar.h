#ifndef MYSLIDEBAR_H
#define MYSLIDEBAR_H

#include <QWidget>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLabel>
#include <QVector>
class MySlideBar : public QWidget
{
    Q_OBJECT
public:
    explicit MySlideBar(QWidget *parent = nullptr);
    
signals:
protected:
    
};

#endif // MYSLIDEBAR_H
