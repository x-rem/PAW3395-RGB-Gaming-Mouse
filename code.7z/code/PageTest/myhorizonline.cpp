#include "myhorizonline.h"


MyHorizonLine::MyHorizonLine(QWidget *parent, QColor color): QWidget(parent)
{
    m_color = color;
    setAttribute(Qt::WA_StyledBackground, true);
    QPalette palette = this->palette();
    palette.setColor(QPalette::Window, m_color); 
    setAutoFillBackground(true);
    setPalette(palette);
}
